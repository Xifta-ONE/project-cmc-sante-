"use client";

import { useCallback, useEffect, useMemo, useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import {
  ArrowUpRight,
  CalendarDays,
  Check,
  ChevronDown,
  CircleCheck,
  ClipboardList,
  Clock,
  Loader2,
  MapPin,
  Phone,
  Sparkles,
  StickyNote,
  UserRound,
  X,
} from "lucide-react";
import Link from "next/link";
import type { Nurse } from "@/db/schema";
import { EASE, Eyebrow } from "@/components/site";
import {
  formatDate,
  StatusBadge,
  type BookingWithNurse,
} from "@/components/tracker";

type Tab = "all" | "pending" | "confirmed" | "done";

const TABS: { key: Tab; label: string }[] = [
  { key: "all", label: "Toutes" },
  { key: "pending", label: "À traiter" },
  { key: "confirmed", label: "Planning" },
  { key: "done", label: "Historique" },
];

export function NurseSpace() {
  const [nurses, setNurses] = useState<Nurse[]>([]);
  const [nurseId, setNurseId] = useState<number | null>(null);
  const [bookings, setBookings] = useState<BookingWithNurse[] | null>(null);
  const [loading, setLoading] = useState(false);
  const [actionId, setActionId] = useState<number | null>(null);
  const [tab, setTab] = useState<Tab>("all");

  useEffect(() => {
    fetch("/api/nurses")
      .then((r) => r.json())
      .then((d) => {
        setNurses(d.nurses ?? []);
        if (d.nurses?.length) setNurseId(d.nurses[0].id);
      })
      .catch(() => setNurses([]));
  }, []);

  const load = useCallback(async (id: number) => {
    setLoading(true);
    try {
      const res = await fetch(`/api/bookings?nurseId=${id}`);
      const data = await res.json();
      setBookings(data.bookings ?? []);
    } catch {
      setBookings([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (nurseId !== null) load(nurseId);
  }, [nurseId, load]);

  const nurse = nurses.find((n) => n.id === nurseId) ?? null;

  const counts = useMemo(() => {
    const c = { pending: 0, confirmed: 0, completed: 0, cancelled: 0 };
    bookings?.forEach((b) => {
      c[b.status] += 1;
    });
    return c;
  }, [bookings]);

  const filtered = useMemo(() => {
    if (!bookings) return [];
    switch (tab) {
      case "pending":
        return bookings.filter((b) => b.status === "pending");
      case "confirmed":
        return bookings.filter((b) => b.status === "confirmed");
      case "done":
        return bookings.filter(
          (b) => b.status === "completed" || b.status === "cancelled",
        );
      default:
        return bookings;
    }
  }, [bookings, tab]);

  async function update(id: number, status: BookingWithNurse["status"]) {
    setActionId(id);
    try {
      const res = await fetch(`/api/bookings/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status }),
      });
      if (!res.ok) throw new Error();
      setBookings((prev) =>
        prev ? prev.map((b) => (b.id === id ? { ...b, status } : b)) : prev,
      );
    } finally {
      setActionId(null);
    }
  }

  return (
    <section className="pb-24 pt-32 md:pt-40">
      <div className="mx-auto max-w-6xl px-5 md:px-8">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: EASE }}
          className="flex flex-wrap items-end justify-between gap-6"
        >
          <div>
            <Eyebrow>Espace infirmier</Eyebrow>
            <h1 className="mt-6 font-display text-5xl font-medium leading-[0.98] tracking-tight text-ink md:text-7xl">
              Vos <em className="font-light text-apricot">visites.</em>
            </h1>
            <p className="mt-5 max-w-lg leading-relaxed text-ink/60">
              Recevez les demandes des patients, confirmez vos créneaux et
              organisez votre tournée de soins à domicile.
            </p>
          </div>
          <div className="relative">
            <UserRound className="pointer-events-none absolute left-4 top-1/2 size-4 -translate-y-1/2 text-moss" />
            <select
              value={nurseId ?? ""}
              onChange={(e) => setNurseId(Number(e.target.value))}
              className="appearance-none rounded-full border border-ink/15 bg-paper py-3.5 pl-11 pr-10 text-sm font-medium text-ink shadow-lg shadow-ink/5 outline-none transition-colors focus:border-pine"
            >
              {nurses.map((n) => (
                <option key={n.id} value={n.id}>
                  {n.name} — {n.city}
                </option>
              ))}
            </select>
            <ChevronDown className="pointer-events-none absolute right-4 top-1/2 size-4 -translate-y-1/2 text-moss" />
          </div>
        </motion.div>

        {/* stats */}
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.12, ease: EASE }}
          className="mt-10 grid grid-cols-2 gap-3 md:grid-cols-4"
        >
          {[
            { icon: Clock, label: "À traiter", value: counts.pending, tone: "bg-gold/15 text-amber-700" },
            { icon: CircleCheck, label: "Confirmées", value: counts.confirmed, tone: "bg-mint text-pine" },
            { icon: Check, label: "Réalisées", value: counts.completed, tone: "bg-pine text-paper" },
            { icon: X, label: "Annulées", value: counts.cancelled, tone: "bg-apricot/15 text-apricot-deep" },
          ].map((s) => (
            <div
              key={s.label}
              className="flex items-center gap-4 rounded-[1.5rem] border border-ink/8 bg-paper p-5"
            >
              <span className={`grid size-11 place-items-center rounded-2xl ${s.tone}`}>
                <s.icon className="size-5" strokeWidth={1.9} />
              </span>
              <div>
                <p className="font-display text-3xl font-medium leading-none text-ink">
                  {s.value}
                </p>
                <p className="mt-1.5 font-mono text-[9px] uppercase tracking-[0.16em] text-ink/45">
                  {s.label}
                </p>
              </div>
            </div>
          ))}
        </motion.div>

        {/* tabs */}
        <div className="mt-8 flex flex-wrap items-center gap-2">
          {TABS.map((t) => (
            <button
              key={t.key}
              onClick={() => setTab(t.key)}
              className={`rounded-full border px-5 py-2.5 font-mono text-[11px] uppercase tracking-[0.14em] transition-all duration-300 ${
                tab === t.key
                  ? "border-pine bg-pine text-paper shadow-lg shadow-pine/20"
                  : "border-ink/15 text-ink/60 hover:border-pine/40 hover:text-ink"
              }`}
            >
              {t.label}
            </button>
          ))}
        </div>

        {/* list */}
        <div className="mt-6">
          {loading ? (
            <div className="grid place-items-center rounded-[2rem] border border-ink/10 bg-paper py-24">
              <Loader2 className="size-6 animate-spin text-moss" />
            </div>
          ) : (
            <AnimatePresence mode="popLayout">
              {filtered.length === 0 ? (
                <motion.div
                  key="empty"
                  initial={{ opacity: 0 }}
                  animate={{ opacity: 1 }}
                  exit={{ opacity: 0 }}
                  className="grid place-items-center rounded-[2rem] border border-dashed border-ink/20 bg-paper/60 px-6 py-20 text-center"
                >
                  <Sparkles className="size-8 text-apricot" />
                  <p className="mt-4 font-display text-2xl text-ink">
                    Rien à afficher ici
                  </p>
                  <p className="mt-2 text-sm text-ink/55">
                    Les nouvelles demandes de patients apparaîtront
                    automatiquement dans cet espace.
                  </p>
                </motion.div>
              ) : (
                <div className="grid gap-4 lg:grid-cols-2">
                  {filtered.map((b, i) => (
                    <motion.article
                      key={b.id}
                      layout
                      initial={{ opacity: 0, y: 20 }}
                      animate={{ opacity: 1, y: 0 }}
                      exit={{ opacity: 0, scale: 0.97 }}
                      transition={{ duration: 0.5, delay: i * 0.04, ease: EASE }}
                      className="flex flex-col rounded-[2rem] border border-ink/10 bg-paper p-6 shadow-lg shadow-ink/5"
                    >
                      <div className="flex items-start justify-between gap-3">
                        <div>
                          <p className="font-display text-2xl font-medium text-ink">
                            {b.patientName}
                          </p>
                          <p className="mt-1 text-[13px] font-medium text-moss">
                            {b.serviceName}
                          </p>
                        </div>
                        <StatusBadge status={b.status} />
                      </div>

                      <div className="mt-5 space-y-2.5 text-[13.5px] text-ink/65">
                        <span className="flex items-center gap-2.5">
                          <CalendarDays className="size-4 shrink-0 text-apricot" />
                          <span className="capitalize">{formatDate(b.date)}</span>{" "}
                          · {b.timeSlot}
                        </span>
                        <span className="flex items-center gap-2.5">
                          <MapPin className="size-4 shrink-0 text-apricot" />
                          {b.address} — {b.city}
                        </span>
                        <span className="flex items-center gap-2.5">
                          <Phone className="size-4 shrink-0 text-apricot" />
                          {b.patientPhone}
                        </span>
                        {b.notes && (
                          <span className="flex items-start gap-2.5 rounded-xl bg-mint-soft px-3.5 py-2.5 text-ink/70">
                            <StickyNote className="mt-0.5 size-4 shrink-0 text-moss" />
                            {b.notes}
                          </span>
                        )}
                      </div>

                      <div className="mt-auto pt-5">
                        <div className="flex flex-wrap items-center justify-between gap-3 border-t border-ink/8 pt-4">
                          <span className="font-mono text-[10px] uppercase tracking-[0.16em] text-ink/40">
                            Réf. {b.reference}
                          </span>
                          <div className="flex gap-2">
                            {b.status === "pending" && (
                              <>
                                <button
                                  onClick={() => update(b.id, "cancelled")}
                                  disabled={actionId === b.id}
                                  className="inline-flex items-center gap-1.5 rounded-full border border-ink/15 px-4 py-2 font-mono text-[10px] uppercase tracking-[0.12em] text-ink/60 transition-colors hover:border-apricot hover:text-apricot-deep disabled:opacity-40"
                                >
                                  <X className="size-3.5" />
                                  Refuser
                                </button>
                                <button
                                  onClick={() => update(b.id, "confirmed")}
                                  disabled={actionId === b.id}
                                  className="inline-flex items-center gap-1.5 rounded-full bg-pine px-4 py-2 font-mono text-[10px] uppercase tracking-[0.12em] text-paper transition-colors hover:bg-pine-deep disabled:opacity-40"
                                >
                                  {actionId === b.id ? (
                                    <Loader2 className="size-3.5 animate-spin" />
                                  ) : (
                                    <Check className="size-3.5" />
                                  )}
                                  Confirmer
                                </button>
                              </>
                            )}
                            {b.status === "confirmed" && (
                              <button
                                onClick={() => update(b.id, "completed")}
                                disabled={actionId === b.id}
                                className="inline-flex items-center gap-1.5 rounded-full bg-ink px-4 py-2 font-mono text-[10px] uppercase tracking-[0.12em] text-paper transition-colors hover:bg-pine disabled:opacity-40"
                              >
                                {actionId === b.id ? (
                                  <Loader2 className="size-3.5 animate-spin" />
                                ) : (
                                  <CircleCheck className="size-3.5" />
                                )}
                                Marquer réalisée
                              </button>
                            )}
                          </div>
                        </div>
                      </div>
                    </motion.article>
                  ))}
                </div>
              )}
            </AnimatePresence>
          )}
        </div>

        {nurse && (
          <div className="mt-10 flex flex-wrap items-center justify-between gap-4 rounded-[2rem] border border-ink/10 bg-mint-soft p-6">
            <div className="flex items-center gap-4">
              <img
                src={nurse.photo}
                alt={nurse.name}
                className="size-14 rounded-2xl object-cover"
              />
              <div>
                <p className="flex items-center gap-2 font-display text-xl font-medium text-ink">
                  <ClipboardList className="size-4 text-moss" />
                  {nurse.name}
                </p>
                <p className="text-[13px] text-ink/55">
                  {nurse.specialty} · {nurse.city}
                </p>
              </div>
            </div>
            <Link
              href={`/infirmiers/${nurse.slug}`}
              className="group inline-flex items-center gap-2 rounded-full border border-pine/30 px-5 py-2.5 font-mono text-[10px] uppercase tracking-[0.14em] text-pine transition-colors hover:bg-pine hover:text-paper"
            >
              Voir mon profil public
              <ArrowUpRight className="size-3.5 transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </Link>
          </div>
        )}
      </div>
    </section>
  );
}

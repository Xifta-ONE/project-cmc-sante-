"use client";

import { useCallback, useEffect, useState } from "react";
import Link from "next/link";
import { motion, AnimatePresence } from "framer-motion";
import {
  ArrowUpRight,
  CalendarDays,
  Check,
  Clock,
  Loader2,
  MapPin,
  Phone,
  Search,
  ShieldQuestion,
  StickyNote,
  X,
} from "lucide-react";
import { EASE, Eyebrow } from "@/components/site";

export type BookingWithNurse = {
  id: number;
  reference: string;
  nurseId: number;
  serviceName: string;
  patientName: string;
  patientPhone: string;
  date: string;
  timeSlot: string;
  address: string;
  city: string;
  notes: string | null;
  status: "pending" | "confirmed" | "completed" | "cancelled";
  createdAt: string;
  nurseName: string;
  nursePhoto: string;
  nurseSlug: string;
};

export const STATUS_META: Record<
  BookingWithNurse["status"],
  { label: string; classes: string }
> = {
  pending: { label: "En attente", classes: "bg-gold/15 text-amber-700" },
  confirmed: { label: "Confirmée", classes: "bg-mint text-pine" },
  completed: { label: "Réalisée", classes: "bg-pine text-paper" },
  cancelled: { label: "Annulée", classes: "bg-apricot/15 text-apricot-deep" },
};

export function StatusBadge({ status }: { status: BookingWithNurse["status"] }) {
  const meta = STATUS_META[status];
  return (
    <span
      className={`inline-flex items-center gap-1.5 rounded-full px-3.5 py-1.5 font-mono text-[10px] uppercase tracking-[0.14em] ${meta.classes}`}
    >
      {status === "pending" && <Clock className="size-3" />}
      {(status === "confirmed" || status === "completed") && (
        <Check className="size-3" />
      )}
      {status === "cancelled" && <X className="size-3" />}
      {meta.label}
    </span>
  );
}

export function formatDate(iso: string) {
  const d = new Date(`${iso}T00:00:00`);
  return d.toLocaleDateString("fr-FR", {
    weekday: "long",
    day: "numeric",
    month: "long",
  });
}

export function StatusStepper({ status }: { status: BookingWithNurse["status"] }) {
  const steps = [
    { key: "pending", label: "Envoyée" },
    { key: "confirmed", label: "Confirmée" },
    { key: "completed", label: "Réalisée" },
  ];
  if (status === "cancelled") {
    return (
      <p className="mt-4 flex items-center gap-2 rounded-xl bg-apricot/10 px-4 py-3 text-[13px] text-apricot-deep">
        <X className="size-4" />
        Cette demande a été annulée.
      </p>
    );
  }
  const activeIndex = status === "pending" ? 0 : status === "confirmed" ? 1 : 2;
  return (
    <div className="mt-5 flex items-center">
      {steps.map((s, i) => (
        <div key={s.key} className="flex flex-1 items-center last:flex-none">
          <div className="flex flex-col items-center gap-1.5">
            <span
              className={`grid size-7 place-items-center rounded-full border text-[10px] font-semibold transition-colors ${
                i <= activeIndex
                  ? "border-pine bg-pine text-paper"
                  : "border-ink/20 text-ink/40"
              }`}
            >
              {i < activeIndex ? <Check className="size-3.5" /> : i + 1}
            </span>
            <span
              className={`font-mono text-[9px] uppercase tracking-[0.1em] ${
                i <= activeIndex ? "text-pine" : "text-ink/35"
              }`}
            >
              {s.label}
            </span>
          </div>
          {i < steps.length - 1 && (
            <div
              className={`mx-2 mb-5 h-px flex-1 transition-colors ${
                i < activeIndex ? "bg-pine" : "bg-ink/15"
              }`}
            />
          )}
        </div>
      ))}
    </div>
  );
}

export function Tracker({ initialPhone = "" }: { initialPhone?: string }) {
  const [phone, setPhone] = useState(initialPhone);
  const [loading, setLoading] = useState(false);
  const [bookings, setBookings] = useState<BookingWithNurse[] | null>(null);
  const [error, setError] = useState("");
  const [cancelling, setCancelling] = useState<number | null>(null);

  const search = useCallback(async (value: string) => {
    if (value.trim().length < 6) return;
    setLoading(true);
    setError("");
    try {
      const res = await fetch(`/api/bookings?phone=${encodeURIComponent(value.trim())}`);
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Erreur de recherche.");
      setBookings(data.bookings);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Erreur de recherche.");
      setBookings(null);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    if (initialPhone) search(initialPhone);
  }, [initialPhone, search]);

  async function cancel(id: number) {
    setCancelling(id);
    try {
      const res = await fetch(`/api/bookings/${id}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ status: "cancelled" }),
      });
      if (!res.ok) throw new Error();
      setBookings((prev) =>
        prev
          ? prev.map((b) => (b.id === id ? { ...b, status: "cancelled" } : b))
          : prev,
      );
    } catch {
      setError("Impossible d'annuler cette demande pour le moment.");
    } finally {
      setCancelling(null);
    }
  }

  return (
    <section className="pb-24 pt-32 md:pt-40">
      <div className="mx-auto max-w-4xl px-5 md:px-8">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: EASE }}
        >
          <Eyebrow>Suivi de vos demandes</Eyebrow>
          <h1 className="mt-6 font-display text-5xl font-medium leading-[0.98] tracking-tight text-ink md:text-7xl">
            Vos <em className="font-light text-apricot">rendez-vous.</em>
          </h1>
          <p className="mt-6 max-w-lg leading-relaxed text-ink/60">
            Entrez le numéro de téléphone utilisé lors de la réservation pour
            suivre l&apos;état de vos demandes de visite.
          </p>
        </motion.div>

        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.15, ease: EASE }}
          className="mt-10 rounded-[2rem] border border-ink/10 bg-paper p-3 shadow-xl shadow-ink/5"
        >
          <form
            onSubmit={(e) => {
              e.preventDefault();
              search(phone);
            }}
            className="flex flex-col gap-2 sm:flex-row"
          >
            <label className="flex flex-1 items-center gap-3 rounded-2xl bg-mint-soft px-5 py-4">
              <Phone className="size-4 shrink-0 text-moss" />
              <input
                value={phone}
                onChange={(e) => setPhone(e.target.value)}
                placeholder="+212 6 12 34 56 78"
                inputMode="tel"
                className="w-full bg-transparent text-sm text-ink outline-none placeholder:text-ink/35"
              />
            </label>
            <button
              type="submit"
              disabled={loading || phone.trim().length < 6}
              className="inline-flex items-center justify-center gap-2 rounded-2xl bg-pine px-7 py-4 text-sm font-medium text-paper transition-colors hover:bg-pine-deep disabled:opacity-40"
            >
              {loading ? (
                <Loader2 className="size-4 animate-spin" />
              ) : (
                <Search className="size-4" />
              )}
              Rechercher
            </button>
          </form>
          <p className="px-2 pb-1 pt-3 font-mono text-[10px] uppercase tracking-[0.14em] text-ink/40">
            Démo — essayez le +212661234567
          </p>
        </motion.div>

        {error && (
          <p className="mt-6 flex items-center gap-2 rounded-2xl bg-apricot/10 px-5 py-4 text-sm text-apricot-deep">
            <ShieldQuestion className="size-4" />
            {error}
          </p>
        )}

        <AnimatePresence mode="wait">
          {bookings && !loading && (
            <motion.div
              key="results"
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0 }}
              transition={{ duration: 0.6, ease: EASE }}
              className="mt-8 space-y-4"
            >
              <p className="font-mono text-[11px] uppercase tracking-[0.18em] text-ink/50">
                {bookings.length} demande{bookings.length > 1 ? "s" : ""} trouvée
                {bookings.length > 1 ? "s" : ""}
              </p>
              {bookings.length === 0 && (
                <div className="rounded-[2rem] border border-dashed border-ink/20 bg-paper/60 px-6 py-16 text-center">
                  <p className="font-display text-2xl text-ink">
                    Aucune demande pour ce numéro
                  </p>
                  <p className="mt-2 text-sm text-ink/55">
                    Vérifiez le numéro saisi ou{" "}
                    <Link href="/infirmiers" className="text-apricot underline">
                      réservez votre première visite
                    </Link>
                    .
                  </p>
                </div>
              )}
              {bookings.map((b) => (
                <article
                  key={b.id}
                  className="rounded-[2rem] border border-ink/10 bg-paper p-6 shadow-lg shadow-ink/5 md:p-7"
                >
                  <div className="flex flex-wrap items-start justify-between gap-3">
                    <div className="flex items-center gap-4">
                      <img
                        src={b.nursePhoto}
                        alt={b.nurseName}
                        className="size-14 rounded-2xl object-cover"
                      />
                      <div>
                        <Link
                          href={`/infirmiers/${b.nurseSlug}`}
                          className="group flex items-center gap-1.5 font-display text-xl font-medium text-ink"
                        >
                          {b.nurseName}
                          <ArrowUpRight className="size-4 text-apricot transition-transform group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
                        </Link>
                        <p className="mt-0.5 text-[13px] text-moss">
                          {b.serviceName}
                        </p>
                      </div>
                    </div>
                    <StatusBadge status={b.status} />
                  </div>

                  <div className="mt-5 grid gap-2.5 text-[13.5px] text-ink/65 sm:grid-cols-2">
                    <span className="flex items-center gap-2.5">
                      <CalendarDays className="size-4 shrink-0 text-apricot" />
                      <span className="capitalize">{formatDate(b.date)}</span> ·{" "}
                      {b.timeSlot}
                    </span>
                    <span className="flex items-center gap-2.5">
                      <MapPin className="size-4 shrink-0 text-apricot" />
                      {b.address} — {b.city}
                    </span>
                    {b.notes && (
                      <span className="flex items-start gap-2.5 sm:col-span-2">
                        <StickyNote className="mt-0.5 size-4 shrink-0 text-apricot" />
                        {b.notes}
                      </span>
                    )}
                  </div>

                  <StatusStepper status={b.status} />

                  <div className="mt-5 flex flex-wrap items-center justify-between gap-3 border-t border-ink/8 pt-4">
                    <span className="font-mono text-[11px] uppercase tracking-[0.18em] text-ink/45">
                      Réf. {b.reference}
                    </span>
                    {(b.status === "pending" || b.status === "confirmed") && (
                      <button
                        onClick={() => cancel(b.id)}
                        disabled={cancelling === b.id}
                        className="inline-flex items-center gap-2 rounded-full border border-apricot/40 px-5 py-2.5 font-mono text-[10px] uppercase tracking-[0.14em] text-apricot-deep transition-colors hover:bg-apricot hover:text-paper disabled:opacity-40"
                      >
                        {cancelling === b.id ? (
                          <Loader2 className="size-3.5 animate-spin" />
                        ) : (
                          <X className="size-3.5" />
                        )}
                        Annuler la demande
                      </button>
                    )}
                  </div>
                </article>
              ))}
            </motion.div>
          )}
        </AnimatePresence>
      </div>
    </section>
  );
}

"use client";

import { useMemo, useState } from "react";
import Link from "next/link";
import { motion, AnimatePresence } from "framer-motion";
import {
  CalendarDays,
  Check,
  ChevronDown,
  CircleAlert,
  Loader2,
  MapPin,
  Send,
  StickyNote,
  User,
  Phone,
} from "lucide-react";
import { EASE } from "@/components/site";

const SLOTS = [
  "08:00 – 10:00",
  "10:00 – 12:00",
  "14:00 – 16:00",
  "16:00 – 18:00",
  "18:00 – 20:00",
];

type ServiceOption = { id: number; name: string; priceFrom: number };

export function BookingForm({
  nurseId,
  nurseName,
  nurseCity,
  services,
}: {
  nurseId: number;
  nurseName: string;
  nurseCity: string;
  services: ServiceOption[];
}) {
  const [serviceName, setServiceName] = useState(services[0]?.name ?? "Soin à domicile");
  const [date, setDate] = useState("");
  const [slot, setSlot] = useState("");
  const [patientName, setPatientName] = useState("");
  const [phone, setPhone] = useState("");
  const [address, setAddress] = useState("");
  const [city, setCity] = useState(nurseCity);
  const [notes, setNotes] = useState("");
  const [state, setState] = useState<
    | { status: "idle" }
    | { status: "submitting" }
    | { status: "success"; reference: string }
    | { status: "error"; message: string }
  >({ status: "idle" });

  const minDate = useMemo(() => new Date().toISOString().slice(0, 10), []);
  const valid =
    date !== "" &&
    slot !== "" &&
    patientName.trim().length >= 3 &&
    phone.trim().length >= 9 &&
    address.trim().length >= 5 &&
    services.length > 0;

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    if (!valid || state.status === "submitting") return;
    setState({ status: "submitting" });
    try {
      const res = await fetch("/api/bookings", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          nurseId,
          serviceName,
          patientName: patientName.trim(),
          patientPhone: phone.trim(),
          date,
          timeSlot: slot,
          address: address.trim(),
          city: city.trim() || nurseCity,
          notes: notes.trim() || null,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.error ?? "Une erreur est survenue.");
      setState({ status: "success", reference: data.booking.reference });
    } catch (err) {
      setState({
        status: "error",
        message:
          err instanceof Error ? err.message : "Une erreur est survenue.",
      });
    }
  }

  if (state.status === "success") {
    return (
      <motion.div
        initial={{ opacity: 0, scale: 0.96 }}
        animate={{ opacity: 1, scale: 1 }}
        transition={{ duration: 0.6, ease: EASE }}
        className="rounded-[1.75rem] bg-mint-soft p-7 text-center"
      >
        <span className="mx-auto grid size-16 place-items-center rounded-full bg-pine text-paper">
          <Check className="size-8" strokeWidth={2.5} />
        </span>
        <h3 className="mt-5 font-display text-3xl font-medium text-ink">
          Demande envoyée !
        </h3>
        <p className="mt-3 text-sm leading-relaxed text-ink/60">
          {nurseName} a reçu votre demande et confirmera très vite (souvent en
          moins d&apos;une heure). Conservez votre référence :
        </p>
        <p className="mx-auto mt-5 w-max rounded-full border border-pine/25 bg-paper px-6 py-3 font-mono text-sm font-semibold tracking-[0.2em] text-pine">
          {state.reference}
        </p>
        <Link
          href={`/rendez-vous?tel=${encodeURIComponent(phone.trim())}`}
          className="mt-6 inline-flex items-center gap-2 rounded-full bg-pine px-6 py-3.5 text-sm font-medium text-paper transition-colors hover:bg-pine-deep"
        >
          Suivre ma demande
          <Send className="size-4" />
        </Link>
      </motion.div>
    );
  }

  return (
    <form onSubmit={submit} className="space-y-4">
      <div>
        <label className="mb-2 block font-mono text-[10px] uppercase tracking-[0.16em] text-ink/50">
          Type de soin
        </label>
        <div className="relative">
          <select
            value={serviceName}
            onChange={(e) => setServiceName(e.target.value)}
            className="w-full appearance-none rounded-2xl border border-ink/12 bg-mint-soft px-5 py-3.5 text-sm font-medium text-ink outline-none transition-colors focus:border-pine"
          >
            {services.map((s) => (
              <option key={s.id} value={s.name}>
                {s.name}
              </option>
            ))}
          </select>
          <ChevronDown className="pointer-events-none absolute right-5 top-1/2 size-4 -translate-y-1/2 text-moss" />
        </div>
      </div>

      <div>
        <label className="mb-2 block font-mono text-[10px] uppercase tracking-[0.16em] text-ink/50">
          Date de la visite
        </label>
        <div className="relative">
          <CalendarDays className="pointer-events-none absolute left-5 top-1/2 size-4 -translate-y-1/2 text-moss" />
          <input
            type="date"
            min={minDate}
            value={date}
            onChange={(e) => setDate(e.target.value)}
            className="w-full rounded-2xl border border-ink/12 bg-mint-soft py-3.5 pl-12 pr-5 text-sm font-medium text-ink outline-none transition-colors focus:border-pine"
          />
        </div>
      </div>

      <div>
        <label className="mb-2 block font-mono text-[10px] uppercase tracking-[0.16em] text-ink/50">
          Créneau souhaité
        </label>
        <div className="flex flex-wrap gap-2">
          {SLOTS.map((s) => (
            <button
              type="button"
              key={s}
              onClick={() => setSlot(s)}
              className={`rounded-full border px-4 py-2 font-mono text-[11px] transition-all duration-300 ${
                slot === s
                  ? "border-pine bg-pine text-paper shadow-lg shadow-pine/25"
                  : "border-ink/15 bg-paper text-ink/70 hover:border-pine/50 hover:text-ink"
              }`}
            >
              {s}
            </button>
          ))}
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-2">
        <div>
          <label className="mb-2 block font-mono text-[10px] uppercase tracking-[0.16em] text-ink/50">
            Nom du patient
          </label>
          <div className="relative">
            <User className="pointer-events-none absolute left-5 top-1/2 size-4 -translate-y-1/2 text-moss" />
            <input
              value={patientName}
              onChange={(e) => setPatientName(e.target.value)}
              placeholder="Nom complet"
              className="w-full rounded-2xl border border-ink/12 bg-mint-soft py-3.5 pl-12 pr-5 text-sm text-ink outline-none transition-colors placeholder:text-ink/35 focus:border-pine"
            />
          </div>
        </div>
        <div>
          <label className="mb-2 block font-mono text-[10px] uppercase tracking-[0.16em] text-ink/50">
            Téléphone
          </label>
          <div className="relative">
            <Phone className="pointer-events-none absolute left-5 top-1/2 size-4 -translate-y-1/2 text-moss" />
            <input
              value={phone}
              onChange={(e) => setPhone(e.target.value)}
              placeholder="+212 6…"
              inputMode="tel"
              className="w-full rounded-2xl border border-ink/12 bg-mint-soft py-3.5 pl-12 pr-5 text-sm text-ink outline-none transition-colors placeholder:text-ink/35 focus:border-pine"
            />
          </div>
        </div>
      </div>

      <div className="grid gap-4 sm:grid-cols-[2fr_1fr]">
        <div>
          <label className="mb-2 block font-mono text-[10px] uppercase tracking-[0.16em] text-ink/50">
            Adresse de la visite
          </label>
          <div className="relative">
            <MapPin className="pointer-events-none absolute left-5 top-1/2 size-4 -translate-y-1/2 text-moss" />
            <input
              value={address}
              onChange={(e) => setAddress(e.target.value)}
              placeholder="N°, rue, quartier, repère…"
              className="w-full rounded-2xl border border-ink/12 bg-mint-soft py-3.5 pl-12 pr-5 text-sm text-ink outline-none transition-colors placeholder:text-ink/35 focus:border-pine"
            />
          </div>
        </div>
        <div>
          <label className="mb-2 block font-mono text-[10px] uppercase tracking-[0.16em] text-ink/50">
            Ville
          </label>
          <input
            value={city}
            onChange={(e) => setCity(e.target.value)}
            className="w-full rounded-2xl border border-ink/12 bg-mint-soft px-5 py-3.5 text-sm text-ink outline-none transition-colors focus:border-pine"
          />
        </div>
      </div>

      <div>
        <label className="mb-2 block font-mono text-[10px] uppercase tracking-[0.16em] text-ink/50">
          Notes pour l&apos;infirmier (optionnel)
        </label>
        <div className="relative">
          <StickyNote className="pointer-events-none absolute left-5 top-4 size-4 text-moss" />
          <textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            rows={2}
            placeholder="Ordonnance, antécédents, étage, digicode…"
            className="w-full resize-none rounded-2xl border border-ink/12 bg-mint-soft py-3.5 pl-12 pr-5 text-sm text-ink outline-none transition-colors placeholder:text-ink/35 focus:border-pine"
          />
        </div>
      </div>

      <AnimatePresence>
        {state.status === "error" && (
          <motion.p
            initial={{ opacity: 0, y: -6 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="flex items-center gap-2 rounded-2xl bg-apricot/10 px-4 py-3 text-[13px] text-apricot-deep"
          >
            <CircleAlert className="size-4 shrink-0" />
            {state.message}
          </motion.p>
        )}
      </AnimatePresence>

      <button
        type="submit"
        disabled={!valid || state.status === "submitting"}
        className="group flex w-full items-center justify-center gap-3 rounded-full bg-apricot py-4 text-sm font-semibold text-paper transition-all duration-300 hover:bg-apricot-deep hover:shadow-xl hover:shadow-apricot/25 disabled:cursor-not-allowed disabled:opacity-40 disabled:hover:shadow-none"
      >
        {state.status === "submitting" ? (
          <>
            <Loader2 className="size-4 animate-spin" />
            Envoi de la demande…
          </>
        ) : (
          <>
            Demander cette visite
            <Send className="size-4 transition-transform duration-300 group-hover:translate-x-1 group-hover:-translate-y-0.5" />
          </>
        )}
      </button>
      <p className="text-center font-mono text-[9px] uppercase tracking-[0.14em] text-ink/40">
        Sans prépaiement — vous réglez l&apos;infirmier sur place
      </p>
    </form>
  );
}

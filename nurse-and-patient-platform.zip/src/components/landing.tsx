"use client";

import Link from "next/link";
import { useRef, useState } from "react";
import {
  motion,
  useScroll,
  useTransform,
  AnimatePresence,
} from "framer-motion";
import {
  ArrowLeft,
  ArrowRight,
  ArrowUpRight,
  CalendarCheck,
  Clock,
  Home,
  MapPin,
  PhoneCall,
  Plus,
  ShieldCheck,
  Star,
  UserRound,
} from "lucide-react";
import type { Nurse, Service } from "@/db/schema";
import {
  Counter,
  EASE,
  Eyebrow,
  LucideIconByName,
  NurseCard,
  Reveal,
  SectionHead,
} from "@/components/site";

const HERO_IMG =
  "https://images.pexels.com/photos/7345459/pexels-photo-7345459.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1100&w=860";
const STEPS_IMG =
  "https://images.pexels.com/photos/7345465/pexels-photo-7345465.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=900&w=760";
const CTA_IMG =
  "https://images.pexels.com/photos/8527647/pexels-photo-8527647.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=800&w=1000";

/* ----------------------------------- hero ----------------------------------- */

export function Hero({ nurses }: { nurses: Nurse[] }) {
  const ref = useRef<HTMLElement>(null);
  const { scrollYProgress } = useScroll({
    target: ref,
    offset: ["start start", "end start"],
  });
  const imgY = useTransform(scrollYProgress, [0, 1], [0, 90]);
  const cardY = useTransform(scrollYProgress, [0, 1], [0, -60]);
  const featured = nurses[0];

  return (
    <section ref={ref} className="relative overflow-hidden pb-14 pt-32 md:pt-40">
      <div
        className="pointer-events-none absolute -left-40 top-10 size-[560px] rounded-full bg-mint blur-[100px]"
        aria-hidden
      />
      <div
        className="pointer-events-none absolute -right-32 bottom-0 size-[460px] rounded-full bg-blush/70 blur-[110px]"
        aria-hidden
      />
      <div className="relative mx-auto grid max-w-7xl gap-14 px-5 md:px-8 lg:grid-cols-12 lg:gap-6">
        <div className="flex flex-col justify-center lg:col-span-7">
          <motion.div
            initial={{ opacity: 0, y: 24 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.1, ease: EASE }}
          >
            <Eyebrow>Plateforme de soins à domicile — Maroc</Eyebrow>
          </motion.div>

          <h1 className="mt-7 font-display text-[clamp(3rem,8.5vw,7rem)] font-medium leading-[0.95] tracking-tight text-ink">
            {["Le soin", "infirmier,"].map((line, i) => (
              <span key={line} className="block overflow-hidden">
                <motion.span
                  className="block"
                  initial={{ y: "110%" }}
                  animate={{ y: 0 }}
                  transition={{ duration: 1, delay: 0.18 + i * 0.1, ease: EASE }}
                >
                  {line}
                </motion.span>
              </span>
            ))}
            <span className="block overflow-hidden">
              <motion.span
                className="block font-light italic text-apricot"
                initial={{ y: "110%" }}
                animate={{ y: 0 }}
                transition={{ duration: 1, delay: 0.38, ease: EASE }}
              >
                à la maison.
              </motion.span>
            </span>
          </h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.5, ease: EASE }}
            className="mt-7 max-w-md leading-relaxed text-ink/60"
          >
            Shifa met en relation patients et infirmiers diplômés pour des soins
            à domicile — injections, perfusions, pansements, suivi
            post-opératoire. Réservé en 2 minutes, confirmé en moins d&apos;une
            heure.
          </motion.p>

          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.9, delay: 0.62, ease: EASE }}
            className="mt-9 flex flex-wrap items-center gap-4"
          >
            <Link
              href="/infirmiers"
              className="group inline-flex items-center gap-3 rounded-full bg-pine py-4 pl-7 pr-3 text-sm font-medium text-paper transition-all duration-300 hover:bg-pine-deep hover:shadow-xl hover:shadow-pine/25"
            >
              Trouver un infirmier
              <span className="grid size-9 place-items-center rounded-full bg-paper/15 transition-transform duration-500 group-hover:rotate-90">
                <ArrowRight className="size-4" />
              </span>
            </Link>
            <Link
              href="#services"
              className="link-underline inline-flex items-center gap-2 py-4 text-sm font-medium text-ink/80"
            >
              Découvrir les soins
              <ArrowUpRight className="size-4" />
            </Link>
          </motion.div>

          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 1, delay: 0.85 }}
            className="mt-12 flex items-center gap-4"
          >
            <div className="flex -space-x-3">
              {nurses.slice(0, 4).map((n) => (
                <img
                  key={n.id}
                  src={n.photo}
                  alt={n.name}
                  className="size-11 rounded-full border-2 border-cream object-cover"
                />
              ))}
              <span className="grid size-11 place-items-center rounded-full border-2 border-cream bg-pine font-mono text-[10px] text-paper">
                +120
              </span>
            </div>
            <div className="text-[13px] leading-snug text-ink/60">
              <span className="flex items-center gap-1 font-semibold text-ink">
                4,9/5 <Star className="size-3.5 fill-gold text-gold" />
              </span>
              2 400+ familles accompagnées
            </div>
          </motion.div>
        </div>

        <div className="relative lg:col-span-5">
          <motion.div
            initial={{ opacity: 0, scale: 0.94, y: 30 }}
            animate={{ opacity: 1, scale: 1, y: 0 }}
            transition={{ duration: 1.2, delay: 0.3, ease: EASE }}
            className="relative"
          >
            <motion.div
              style={{ y: imgY }}
              className="relative overflow-hidden rounded-b-[2rem] rounded-t-[14rem] border border-ink/10 shadow-2xl shadow-pine/20"
            >
              <img
                src={HERO_IMG}
                alt="Infirmière prenant la tension d'une patiente à domicile"
                className="aspect-[4/5] w-full object-cover"
              />
              <div className="absolute inset-x-0 bottom-0 h-40 bg-gradient-to-t from-pine-deep/60 to-transparent" />
              <svg
                viewBox="0 0 320 60"
                className="absolute bottom-6 left-6 w-48 text-emerald-300"
                fill="none"
              >
                <path
                  className="ecg-line"
                  d="M0 30 H60 L75 30 85 8 100 52 112 18 122 30 H160 L172 30 182 4 197 56 209 16 219 30 H260 L272 30 282 10 296 48 306 30 H320"
                  stroke="currentColor"
                  strokeWidth="2.4"
                  strokeLinecap="round"
                  strokeLinejoin="round"
                />
              </svg>
            </motion.div>

            {featured && (
              <motion.div
                style={{ y: cardY }}
                initial={{ opacity: 0, x: -24 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 1, delay: 0.9, ease: EASE }}
                className="absolute -left-4 top-10 md:-left-10"
              >
                <Link
                  href={`/infirmiers/${featured.slug}`}
                  className="animate-float-slow flex items-center gap-3 rounded-2xl border border-ink/8 bg-paper/95 p-3 pr-5 shadow-xl shadow-ink/10 backdrop-blur"
                >
                  <img
                    src={featured.photo}
                    alt={featured.name}
                    className="size-12 rounded-xl object-cover"
                  />
                  <div>
                    <p className="flex items-center gap-1.5 text-[13px] font-semibold text-ink">
                      {featured.name.split(" ")[0]} {featured.name.split(" ")[1]}
                      <ShieldCheck className="size-3.5 text-moss" />
                    </p>
                    <p className="text-[11px] text-ink/55">
                      {featured.specialty} · {featured.city}
                    </p>
                  </div>
                </Link>
              </motion.div>
            )}

            <motion.div
              initial={{ opacity: 0, x: 24 }}
              animate={{ opacity: 1, x: 0 }}
              transition={{ duration: 1, delay: 1.05, ease: EASE }}
              className="absolute -right-3 bottom-24 md:-right-8"
            >
              <div className="animate-float-slow flex items-center gap-2.5 rounded-full border border-ink/8 bg-pine px-4 py-2.5 text-paper shadow-xl shadow-pine/30 [animation-delay:1.2s]">
                <Clock className="size-4" />
                <span className="font-mono text-[10px] uppercase tracking-[0.14em]">
                  Prochaine dispo · aujourd&apos;hui 14h
                </span>
              </div>
            </motion.div>
          </motion.div>
        </div>
      </div>
    </section>
  );
}

/* ---------------------------------- marquee --------------------------------- */

export function Marquee({ services }: { services: Service[] }) {
  const items = [...services, ...services];
  return (
    <div className="rotate-[-1.2deg] border-y border-paper/10 bg-pine py-4">
      <div className="animate-marquee flex w-max items-center gap-8">
        {items.map((s, i) => (
          <span
            key={`${s.id}-${i}`}
            className="flex items-center gap-8 text-paper"
          >
            <span className="font-display text-lg italic">{s.name}</span>
            <Plus className="size-4 text-apricot" />
          </span>
        ))}
      </div>
    </div>
  );
}

/* ----------------------------------- stats ---------------------------------- */

const STATS = [
  { value: 2400, suffix: "+", label: "Visites réalisées à domicile" },
  { value: 98, suffix: "%", label: "De patients satisfaits" },
  { value: 45, suffix: " min", label: "Délai moyen de réponse" },
  { value: 6, suffix: "", label: "Villes couvertes au Maroc" },
];

export function Stats() {
  return (
    <section className="mx-auto max-w-7xl px-5 py-16 md:px-8 md:py-24">
      <div className="grid gap-px overflow-hidden rounded-[2rem] border border-ink/8 bg-ink/8 sm:grid-cols-2 lg:grid-cols-4">
        {STATS.map((s, i) => (
          <Reveal key={s.label} delay={i * 0.08} className="h-full">
            <div className="flex h-full flex-col gap-2 bg-paper p-8 transition-colors duration-500 hover:bg-mint-soft">
              <Counter
                value={s.value}
                suffix={s.suffix}
                className="font-display text-5xl font-medium tracking-tight text-pine md:text-6xl"
              />
              <p className="text-[13px] text-ink/55">{s.label}</p>
            </div>
          </Reveal>
        ))}
      </div>
    </section>
  );
}

/* ---------------------------------- services -------------------------------- */

export function ServicesSection({ services }: { services: Service[] }) {
  return (
    <section id="services" className="relative py-16 md:py-24">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <SectionHead
            eyebrow="Nos soins à domicile"
            title={
              <>
                Tous les gestes du quotidien,{" "}
                <em className="font-light text-apricot">sans vous déplacer.</em>
              </>
            }
          />
          <Reveal delay={0.2}>
            <Link
              href="/infirmiers"
              className="group inline-flex items-center gap-2 rounded-full border border-ink/15 px-6 py-3 font-mono text-[11px] uppercase tracking-[0.15em] text-ink transition-colors hover:bg-ink hover:text-paper"
            >
              Réserver un soin
              <ArrowUpRight className="size-4 transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </Link>
          </Reveal>
        </div>

        <div className="mt-14 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
          {services.map((s, i) => (
            <Reveal key={s.id} delay={(i % 4) * 0.07} className="h-full">
              <Link
                href={`/infirmiers?soin=${encodeURIComponent(s.name)}`}
                className="group relative flex h-full flex-col overflow-hidden rounded-[2rem] border border-ink/8 bg-paper p-7 transition-all duration-500 hover:-translate-y-1.5 hover:border-pine/25 hover:shadow-xl hover:shadow-pine/10"
              >
                <div
                  className="absolute -right-10 -top-10 size-32 rounded-full bg-mint-soft transition-transform duration-700 group-hover:scale-[2.6]"
                  aria-hidden
                />
                <div className="relative">
                  <span className="grid size-12 place-items-center rounded-2xl bg-pine text-paper transition-colors duration-500 group-hover:bg-apricot">
                    <LucideIconByName name={s.icon} className="size-6" />
                  </span>
                  <h3 className="mt-6 font-display text-2xl font-medium leading-tight text-ink">
                    {s.name}
                  </h3>
                  <p className="mt-3 text-[13.5px] leading-relaxed text-ink/55">
                    {s.description}
                  </p>
                  <div className="mt-6 flex items-center justify-between border-t border-ink/8 pt-4 font-mono text-[10px] uppercase tracking-[0.14em] text-ink/50">
                    <span>dès {s.priceFrom} MAD</span>
                    <span className="flex items-center gap-1">
                      <Clock className="size-3" />
                      {s.durationMin} min
                    </span>
                  </div>
                </div>
              </Link>
            </Reveal>
          ))}
        </div>
      </div>
    </section>
  );
}

/* -------------------------------- how it works ------------------------------- */

const STEPS = [
  {
    icon: UserRound,
    num: "01",
    title: "Décrivez votre besoin",
    copy: "Choisissez le soin, la date et le créneau qui vous arrangent. Indiquez l'adresse du patient — c'est tout.",
  },
  {
    icon: ShieldCheck,
    num: "02",
    title: "Rencontrez votre infirmier",
    copy: "Chaque infirmier est diplômé, vérifié et noté par la communauté. Vous recevez sa confirmation en moins d'une heure.",
  },
  {
    icon: Home,
    num: "03",
    title: "Recevez le soin chez vous",
    copy: "L'infirmier arrive avec tout le matériel nécessaire. Suivez chaque étape de la visite depuis votre espace.",
  },
];

export function HowItWorks() {
  return (
    <section id="comment" className="mx-auto max-w-7xl px-5 py-16 md:px-8 md:py-24">
      <div className="grid items-center gap-14 lg:grid-cols-12">
        <div className="relative lg:col-span-5">
          <Reveal>
            <div className="relative overflow-hidden rounded-b-[2rem] rounded-t-[12rem] border border-ink/10">
              <img
                src={STEPS_IMG}
                alt="Infirmière auscultant un patient à domicile"
                className="aspect-[4/5] w-full object-cover"
                loading="lazy"
              />
            </div>
            <div className="absolute -bottom-6 -right-4 rounded-2xl bg-apricot px-6 py-5 text-paper shadow-xl shadow-apricot/30 md:-right-8">
              <p className="font-display text-4xl font-medium">2 min</p>
              <p className="mt-1 font-mono text-[10px] uppercase tracking-[0.16em] text-paper/80">
                pour réserver
              </p>
            </div>
          </Reveal>
        </div>

        <div className="lg:col-span-7">
          <SectionHead
            eyebrow="Comment ça marche"
            title={
              <>
                Trois étapes,{" "}
                <em className="font-light text-apricot">zéro friction.</em>
              </>
            }
          />
          <div className="mt-12 space-y-2">
            {STEPS.map((s, i) => (
              <Reveal key={s.num} delay={i * 0.1}>
                <div className="group flex gap-6 rounded-[2rem] border border-transparent p-6 transition-all duration-500 hover:border-ink/10 hover:bg-paper md:gap-10 md:p-8">
                  <span className="text-stroke font-display text-6xl font-semibold leading-none md:text-7xl">
                    {s.num}
                  </span>
                  <div>
                    <h3 className="flex items-center gap-3 font-display text-2xl font-medium text-ink">
                      <s.icon className="size-5 text-moss" strokeWidth={1.8} />
                      {s.title}
                    </h3>
                    <p className="mt-2.5 max-w-md text-[14px] leading-relaxed text-ink/55">
                      {s.copy}
                    </p>
                  </div>
                </div>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

/* ------------------------------- featured nurses ----------------------------- */

export function FeaturedNurses({ nurses }: { nurses: Nurse[] }) {
  return (
    <section className="relative overflow-hidden bg-mint-soft py-16 md:py-24">
      <div
        className="pointer-events-none absolute -left-24 top-0 size-[400px] rounded-full bg-mint blur-[90px]"
        aria-hidden
      />
      <div className="relative mx-auto max-w-7xl px-5 md:px-8">
        <div className="flex flex-wrap items-end justify-between gap-6">
          <SectionHead
            eyebrow="Nos infirmiers partenaires"
            title={
              <>
                Des professionnels{" "}
                <em className="font-light text-apricot">vérifiés,</em> près de
                chez vous.
              </>
            }
          />
          <Reveal delay={0.2}>
            <Link
              href="/infirmiers"
              className="group inline-flex items-center gap-2 rounded-full bg-ink px-6 py-3 font-mono text-[11px] uppercase tracking-[0.15em] text-paper transition-colors hover:bg-pine"
            >
              Tous les infirmiers
              <ArrowRight className="size-4 transition-transform duration-300 group-hover:translate-x-1" />
            </Link>
          </Reveal>
        </div>
        <div className="mt-14 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
          {nurses.map((n, i) => (
            <NurseCard key={n.id} nurse={n} index={i} />
          ))}
        </div>
      </div>
    </section>
  );
}

/* -------------------------------- testimonials ------------------------------- */

const TESTIMONIALS = [
  {
    quote:
      "Ma mère avait besoin de pansements quotidiens après son opération. En dix minutes, j'avais réservé une infirmière formidable qui est venue chaque jour à 9h précises. On se serait cru à l'hôpital — en mieux.",
    name: "Salma Berrada",
    role: "Pour sa mère — Casablanca",
  },
  {
    quote:
      "Les perfusions de mon père se font désormais au salon, avec sa théière à côté. L'infirmier est devenu un ami de la famille. Ce service a changé notre quotidien.",
    name: "Yassine El Mansouri",
    role: "Pour son père — Rabat",
  },
  {
    quote:
      "Jeune maman épuisée, j'avais peur de mal faire avec bébé. Les visites de suivi à domicile m'ont redonné confiance en quelques jours. Merci pour cette douceur.",
    name: "Imane Chafik",
    role: "Suivi maman & nouveau-né — Rabat",
  },
];

export function Testimonials() {
  const [index, setIndex] = useState(0);
  const t = TESTIMONIALS[index];

  return (
    <section className="relative overflow-hidden bg-pine-deep py-20 text-paper md:py-28">
      <div
        className="pointer-events-none absolute right-[-10%] top-[-20%] size-[560px] rounded-full bg-moss/30 blur-[130px]"
        aria-hidden
      />
      <span
        className="pointer-events-none absolute left-8 top-10 select-none font-display text-[16rem] italic leading-none text-paper/5"
        aria-hidden
      >
        &ldquo;
      </span>
      <div className="relative mx-auto max-w-5xl px-5 md:px-8">
        <div className="flex justify-center">
          <Eyebrow light>Ils nous confient leurs proches</Eyebrow>
        </div>
        <div className="relative mt-10 min-h-[240px] md:min-h-[200px]">
          <AnimatePresence mode="wait">
            <motion.blockquote
              key={index}
              initial={{ opacity: 0, y: 24 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -24 }}
              transition={{ duration: 0.7, ease: EASE }}
              className="text-center"
            >
              <p className="font-display text-2xl font-light leading-snug tracking-tight md:text-4xl">
                &ldquo;{t.quote}&rdquo;
              </p>
              <footer className="mt-8">
                <p className="font-semibold">{t.name}</p>
                <p className="mt-1 font-mono text-[10px] uppercase tracking-[0.18em] text-paper/50">
                  {t.role}
                </p>
              </footer>
            </motion.blockquote>
          </AnimatePresence>
        </div>
        <div className="mt-10 flex items-center justify-center gap-4">
          <button
            aria-label="Témoignage précédent"
            onClick={() =>
              setIndex((index - 1 + TESTIMONIALS.length) % TESTIMONIALS.length)
            }
            className="grid size-12 place-items-center rounded-full border border-paper/20 text-paper transition-all hover:bg-paper hover:text-pine-deep"
          >
            <ArrowLeft className="size-4" />
          </button>
          <div className="flex gap-2">
            {TESTIMONIALS.map((_, i) => (
              <button
                key={i}
                aria-label={`Témoignage ${i + 1}`}
                onClick={() => setIndex(i)}
                className={`h-1.5 rounded-full transition-all duration-500 ${
                  i === index ? "w-8 bg-apricot" : "w-1.5 bg-paper/25"
                }`}
              />
            ))}
          </div>
          <button
            aria-label="Témoignage suivant"
            onClick={() => setIndex((index + 1) % TESTIMONIALS.length)}
            className="grid size-12 place-items-center rounded-full border border-paper/20 text-paper transition-all hover:bg-paper hover:text-pine-deep"
          >
            <ArrowRight className="size-4" />
          </button>
        </div>
      </div>
    </section>
  );
}

/* ----------------------------------- cities ---------------------------------- */

export function Cities({ nurses }: { nurses: Nurse[] }) {
  const counts = nurses.reduce<Record<string, number>>((acc, n) => {
    acc[n.city] = (acc[n.city] ?? 0) + 1;
    return acc;
  }, {});
  const cities = Object.entries(counts).sort((a, b) => b[1] - a[1]);

  return (
    <section className="mx-auto max-w-7xl px-5 py-16 md:px-8 md:py-24">
      <div className="grid gap-10 lg:grid-cols-12 lg:items-center">
        <div className="lg:col-span-4">
          <SectionHead
            eyebrow="Couverture"
            title={
              <>
                Où que vous soyez,{" "}
                <em className="font-light text-apricot">on arrive.</em>
              </>
            }
            copy="Un réseau d'infirmiers partenaires dans les grandes villes du Royaume — et de nouvelles zones chaque mois."
          />
        </div>
        <div className="lg:col-span-8">
          <div className="flex flex-wrap gap-3">
            {cities.map(([city, count], i) => (
              <Reveal key={city} delay={i * 0.05}>
                <Link
                  href={`/infirmiers?ville=${encodeURIComponent(city)}`}
                  className="group inline-flex items-center gap-3 rounded-full border border-ink/12 bg-paper px-6 py-4 transition-all duration-400 hover:-translate-y-1 hover:border-pine hover:bg-pine hover:text-paper"
                >
                  <MapPin className="size-4 text-apricot" />
                  <span className="font-display text-xl">{city}</span>
                  <span className="font-mono text-[10px] uppercase tracking-[0.14em] opacity-50">
                    {count} infirmier{count > 1 ? "s" : ""}
                  </span>
                </Link>
              </Reveal>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
}

/* ------------------------------------ CTA ------------------------------------ */

export function CtaSection() {
  return (
    <section className="mx-auto max-w-7xl px-5 pb-24 pt-4 md:px-8">
      <Reveal>
        <div className="relative overflow-hidden rounded-[2.5rem] bg-pine">
          <div
            className="pointer-events-none absolute -left-20 -top-20 size-[420px] rounded-full bg-moss/40 blur-[100px]"
            aria-hidden
          />
          <div className="grid lg:grid-cols-12">
            <div className="relative p-10 md:p-16 lg:col-span-7">
              <Eyebrow light>Une visite aujourd&apos;hui ?</Eyebrow>
              <h2 className="mt-6 font-display text-4xl font-medium leading-[1.02] tracking-tight text-paper md:text-6xl">
                Un infirmier chez vous{" "}
                <em className="font-light text-blush">dès ce soir.</em>
              </h2>
              <p className="mt-6 max-w-md leading-relaxed text-paper/65">
                Décrivez le soin, choisissez votre créneau — votre infirmier
                confirme en moins d&apos;une heure et arrive avec tout le
                matériel.
              </p>
              <div className="mt-9 flex flex-wrap gap-4">
                <Link
                  href="/infirmiers"
                  className="group inline-flex items-center gap-3 rounded-full bg-apricot py-4 pl-7 pr-3 text-sm font-semibold text-paper transition-all duration-300 hover:bg-apricot-deep hover:shadow-xl hover:shadow-apricot/20"
                >
                  Réserver une visite
                  <span className="grid size-9 place-items-center rounded-full bg-paper/20 transition-transform duration-500 group-hover:rotate-90">
                    <ArrowRight className="size-4" />
                  </span>
                </Link>
                <a
                  href="#comment"
                  className="inline-flex items-center gap-3 rounded-full border border-paper/25 px-7 py-4 text-sm font-medium text-paper transition-colors hover:bg-paper/10"
                >
                  <PhoneCall className="size-4" />
                  Comment ça marche
                </a>
              </div>
              <div className="mt-10 flex items-center gap-2.5 font-mono text-[10px] uppercase tracking-[0.16em] text-paper/50">
                <CalendarCheck className="size-4 text-apricot" />
                Confirmation sous 1h · Annulation gratuite jusqu&apos;à 2h avant
              </div>
            </div>
            <div className="relative min-h-[280px] lg:col-span-5">
              <img
                src={CTA_IMG}
                alt="Infirmier discutant du traitement avec une patiente"
                className="absolute inset-0 h-full w-full object-cover"
                loading="lazy"
              />
              <div className="absolute inset-0 bg-gradient-to-r from-pine via-pine/30 to-transparent lg:bg-gradient-to-r" />
            </div>
          </div>
        </div>
      </Reveal>
    </section>
  );
}

"use client";

import Link from "next/link";
import { usePathname } from "next/navigation";
import { useEffect, useRef, useState, type ReactNode } from "react";
import {
  motion,
  useInView,
  useMotionValueEvent,
  useScroll,
  animate,
} from "framer-motion";
import {
  Activity,
  Baby,
  Bandage,
  Droplets,
  HeartHandshake,
  MapPin,
  Menu,
  Phone,
  Plus,
  ShieldCheck,
  ShowerHead,
  Star,
  Stethoscope,
  Syringe,
  X,
  type LucideIcon,
} from "lucide-react";
import type { Nurse } from "@/db/schema";

export const EASE = [0.22, 1, 0.36, 1] as const;

/* ---------------------------------- icons --------------------------------- */

const ICONS: Record<string, LucideIcon> = {
  Syringe,
  Droplets,
  Bandage,
  Stethoscope,
  Activity,
  HeartHandshake,
  Baby,
  ShowerHead,
};

export function LucideIconByName({
  name,
  className,
}: {
  name: string;
  className?: string;
}) {
  const Icon = ICONS[name] ?? Stethoscope;
  return <Icon className={className} strokeWidth={1.6} />;
}

/* ---------------------------------- logo ---------------------------------- */

export function Logo({ light = false }: { light?: boolean }) {
  return (
    <Link href="/" className="group flex items-center gap-2.5">
      <span className="grid size-9 place-items-center rounded-xl bg-pine text-paper transition-transform duration-500 group-hover:rotate-90">
        <Plus className="size-5" strokeWidth={2.4} />
      </span>
      <span
        className={`font-display text-2xl font-semibold tracking-tight ${
          light ? "text-paper" : "text-ink"
        }`}
      >
        Shifa
      </span>
    </Link>
  );
}

/* ---------------------------------- navbar --------------------------------- */

const NAV_LINKS = [
  { href: "/", label: "Accueil" },
  { href: "/infirmiers", label: "Infirmiers" },
  { href: "/#services", label: "Soins" },
  { href: "/rendez-vous", label: "Suivi RDV" },
  { href: "/espace-infirmier", label: "Espace infirmier" },
];

export function Navbar() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);
  const pathname = usePathname();
  const { scrollY } = useScroll();

  useMotionValueEvent(scrollY, "change", (v) => setScrolled(v > 40));

  useEffect(() => {
    setOpen(false);
  }, [pathname]);

  return (
    <>
      <motion.header
        initial={{ y: -80, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ duration: 0.9, ease: EASE }}
        className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${
          scrolled
            ? "border-b border-ink/8 bg-cream/85 backdrop-blur-xl"
            : "bg-transparent"
        }`}
      >
        <div className="mx-auto flex h-16 max-w-7xl items-center justify-between px-5 md:h-20 md:px-8">
          <Logo />
          <nav className="hidden items-center gap-8 lg:flex">
            {NAV_LINKS.map((l) => (
              <Link
                key={l.href}
                href={l.href}
                className={`link-underline font-mono text-[11px] uppercase tracking-[0.18em] transition-colors ${
                  pathname === l.href
                    ? "text-apricot"
                    : "text-ink/70 hover:text-ink"
                }`}
              >
                {l.label}
              </Link>
            ))}
          </nav>
          <div className="flex items-center gap-3">
            <Link
              href="/infirmiers"
              className="hidden items-center gap-2 rounded-full bg-pine px-5 py-2.5 font-mono text-[11px] uppercase tracking-[0.15em] text-paper transition-all duration-300 hover:bg-pine-deep hover:shadow-lg hover:shadow-pine/25 sm:inline-flex"
            >
              Réserver
              <Plus className="size-3.5" />
            </Link>
            <button
              onClick={() => setOpen(!open)}
              aria-label="Menu"
              className="grid size-10 place-items-center rounded-full border border-ink/15 text-ink lg:hidden"
            >
              {open ? <X className="size-4" /> : <Menu className="size-4" />}
            </button>
          </div>
        </div>
      </motion.header>

      {open && (
        <motion.div
          initial={{ opacity: 0, y: -12 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.4, ease: EASE }}
          className="fixed inset-x-4 top-20 z-50 rounded-3xl border border-ink/10 bg-paper p-6 shadow-2xl shadow-ink/15 lg:hidden"
        >
          <nav className="flex flex-col gap-1">
            {NAV_LINKS.map((l, i) => (
              <motion.div
                key={l.href}
                initial={{ opacity: 0, x: -14 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ delay: 0.05 * i, duration: 0.4, ease: EASE }}
              >
                <Link
                  href={l.href}
                  className="flex items-center justify-between rounded-2xl px-4 py-3.5 font-display text-2xl text-ink transition-colors hover:bg-mint-soft"
                >
                  {l.label}
                  <span className="font-mono text-[10px] text-ink/40">
                    0{i + 1}
                  </span>
                </Link>
              </motion.div>
            ))}
          </nav>
          <Link
            href="/infirmiers"
            className="mt-4 flex items-center justify-center gap-2 rounded-full bg-pine px-5 py-4 font-mono text-[11px] uppercase tracking-[0.15em] text-paper"
          >
            Réserver une visite
            <Plus className="size-3.5" />
          </Link>
        </motion.div>
      )}
    </>
  );
}

/* ---------------------------------- footer -------------------------------- */

export function Footer() {
  return (
    <footer className="relative overflow-hidden bg-pine-deep text-paper">
      <div
        className="pointer-events-none absolute -top-40 right-0 size-[480px] rounded-full bg-moss/25 blur-[120px]"
        aria-hidden
      />
      <div className="mx-auto max-w-7xl px-5 pb-10 pt-20 md:px-8">
        <div className="grid gap-14 lg:grid-cols-12">
          <div className="lg:col-span-5">
            <Logo light />
            <p className="mt-6 max-w-sm text-sm leading-relaxed text-paper/60">
              La plateforme qui met en relation patients et infirmiers diplômés
              pour des soins à domicile, simples, sûrs et humains — partout au
              Maroc.
            </p>
            <div className="mt-8 flex items-center gap-3 rounded-2xl border border-paper/15 bg-paper/5 p-4">
              <span className="grid size-10 shrink-0 place-items-center rounded-full bg-apricot text-paper">
                <Phone className="size-4" />
              </span>
              <div>
                <p className="font-mono text-[10px] uppercase tracking-[0.18em] text-paper/50">
                  Urgence vitale
                </p>
                <p className="text-sm text-paper/85">
                  Contactez le SAMU — <span className="font-semibold">141</span>
                </p>
              </div>
            </div>
          </div>
          <div className="grid grid-cols-2 gap-10 sm:grid-cols-3 lg:col-span-7">
            <div>
              <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-paper/40">
                Navigation
              </p>
              <ul className="mt-5 space-y-3 text-sm">
                {NAV_LINKS.map((l) => (
                  <li key={l.href}>
                    <Link
                      href={l.href}
                      className="text-paper/70 transition-colors hover:text-paper"
                    >
                      {l.label}
                    </Link>
                  </li>
                ))}
              </ul>
            </div>
            <div>
              <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-paper/40">
                Soins populaires
              </p>
              <ul className="mt-5 space-y-3 text-sm text-paper/70">
                <li>Injections & perfusions</li>
                <li>Pansements & cicatrisation</li>
                <li>Soins post-opératoires</li>
                <li>Suivi diabétique</li>
                <li>Maman & nouveau-né</li>
              </ul>
            </div>
            <div>
              <p className="font-mono text-[10px] uppercase tracking-[0.2em] text-paper/40">
                Villes couvertes
              </p>
              <ul className="mt-5 space-y-3 text-sm text-paper/70">
                {["Casablanca", "Rabat", "Marrakech", "Fès", "Tanger", "Agadir"].map(
                  (c) => (
                    <li key={c} className="flex items-center gap-2">
                      <MapPin className="size-3 text-apricot" />
                      {c}
                    </li>
                  ),
                )}
              </ul>
            </div>
          </div>
        </div>
        <div className="mt-16 select-none overflow-hidden" aria-hidden>
          <p className="text-stroke-cream whitespace-nowrap text-center font-display text-[18vw] font-semibold leading-none tracking-tight">
            shifa
          </p>
        </div>
        <div className="mt-6 flex flex-col items-center justify-between gap-3 border-t border-paper/10 pt-6 font-mono text-[10px] uppercase tracking-[0.16em] text-paper/40 md:flex-row">
          <p>© {new Date().getFullYear()} Shifa — Soins infirmiers à domicile</p>
          <p className="flex items-center gap-2">
            <ShieldCheck className="size-3.5 text-apricot" />
            Infirmiers vérifiés · Diplômes contrôlés
          </p>
        </div>
      </div>
    </footer>
  );
}

/* ------------------------------- motion utils ------------------------------ */

export function Reveal({
  children,
  delay = 0,
  y = 32,
  className,
}: {
  children: ReactNode;
  delay?: number;
  y?: number;
  className?: string;
}) {
  return (
    <motion.div
      initial={{ opacity: 0, y }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: "-60px" }}
      transition={{ duration: 0.9, delay, ease: EASE }}
      className={className}
    >
      {children}
    </motion.div>
  );
}

export function Eyebrow({
  children,
  light = false,
}: {
  children: ReactNode;
  light?: boolean;
}) {
  return (
    <p
      className={`flex items-center gap-2.5 font-mono text-[10px] uppercase tracking-[0.24em] md:text-[11px] ${
        light ? "text-paper/60" : "text-moss"
      }`}
    >
      <span className="relative flex size-2">
        <span className="animate-pulse-soft absolute inline-flex size-full rounded-full bg-apricot" />
        <span className="relative inline-flex size-2 rounded-full bg-apricot" />
      </span>
      {children}
    </p>
  );
}

export function SectionHead({
  eyebrow,
  title,
  copy,
  light = false,
  align = "left",
}: {
  eyebrow: string;
  title: ReactNode;
  copy?: string;
  light?: boolean;
  align?: "left" | "center";
}) {
  return (
    <div
      className={`max-w-2xl ${align === "center" ? "mx-auto text-center" : ""}`}
    >
      <Reveal>
        <div className={align === "center" ? "flex justify-center" : ""}>
          <Eyebrow light={light}>{eyebrow}</Eyebrow>
        </div>
      </Reveal>
      <Reveal delay={0.08}>
        <h2
          className={`mt-5 font-display text-4xl font-medium leading-[1.05] tracking-tight md:text-6xl ${
            light ? "text-paper" : "text-ink"
          }`}
        >
          {title}
        </h2>
      </Reveal>
      {copy && (
        <Reveal delay={0.16}>
          <p
            className={`mt-5 leading-relaxed ${
              light ? "text-paper/60" : "text-ink/60"
            }`}
          >
            {copy}
          </p>
        </Reveal>
      )}
    </div>
  );
}

export function Counter({
  value,
  suffix = "",
  className,
}: {
  value: number;
  suffix?: string;
  className?: string;
}) {
  const ref = useRef<HTMLSpanElement>(null);
  const inView = useInView(ref, { once: true, margin: "-40px" });
  const [display, setDisplay] = useState(0);

  useEffect(() => {
    if (!inView) return;
    const controls = animate(0, value, {
      duration: 1.8,
      ease: [0.22, 1, 0.36, 1],
      onUpdate: (v) => setDisplay(Math.round(v)),
    });
    return () => controls.stop();
  }, [inView, value]);

  return (
    <span ref={ref} className={className}>
      {display.toLocaleString("fr-FR")}
      {suffix}
    </span>
  );
}

export function Stars({ rating, className }: { rating: number; className?: string }) {
  return (
    <span className={`inline-flex items-center gap-0.5 ${className ?? ""}`}>
      {[1, 2, 3, 4, 5].map((i) => (
        <Star
          key={i}
          className={`size-3.5 ${
            i <= Math.round(rating)
              ? "fill-gold text-gold"
              : "fill-ink/10 text-ink/10"
          }`}
        />
      ))}
    </span>
  );
}

/* -------------------------------- nurse card ------------------------------- */

export function NurseCard({ nurse, index = 0 }: { nurse: Nurse; index?: number }) {
  return (
    <Reveal delay={index * 0.07} className="h-full">
      <Link
        href={`/infirmiers/${nurse.slug}`}
        className="group flex h-full flex-col rounded-[2rem] border border-ink/8 bg-paper p-3 transition-all duration-500 hover:-translate-y-2 hover:border-pine/30 hover:shadow-2xl hover:shadow-pine/15"
      >
        <div className="relative overflow-hidden rounded-[1.5rem] rounded-t-[10rem] bg-mint">
          <img
            src={nurse.photo}
            alt={`Portrait de ${nurse.name}`}
            className="aspect-[4/5] w-full object-cover transition-transform duration-700 ease-out group-hover:scale-105"
            loading="lazy"
          />
          <div className="absolute inset-x-3 bottom-3 flex items-center justify-between">
            <span className="inline-flex items-center gap-1.5 rounded-full bg-paper/90 px-3 py-1.5 font-mono text-[10px] uppercase tracking-[0.12em] text-ink backdrop-blur">
              <Star className="size-3 fill-gold text-gold" />
              {nurse.rating.toFixed(1)} · {nurse.reviewsCount} avis
            </span>
            {nurse.availableToday && (
              <span className="inline-flex items-center gap-1.5 rounded-full bg-pine px-3 py-1.5 font-mono text-[10px] uppercase tracking-[0.12em] text-paper">
                <span className="animate-pulse-soft size-1.5 rounded-full bg-emerald-300" />
                Aujourd&apos;hui
              </span>
            )}
          </div>
          {nurse.verified && (
            <span className="absolute left-3 top-3 grid size-8 place-items-center rounded-full bg-apricot text-paper shadow-lg shadow-apricot/30">
              <ShieldCheck className="size-4" />
            </span>
          )}
        </div>
        <div className="flex flex-1 flex-col px-2 pb-2 pt-4">
          <div className="flex items-start justify-between gap-2">
            <div>
              <h3 className="font-display text-xl font-medium leading-tight text-ink">
                {nurse.name}
              </h3>
              <p className="mt-1 text-[13px] text-moss">{nurse.specialty}</p>
            </div>
          </div>
          <div className="mt-auto flex items-center justify-between border-t border-ink/8 pt-3 text-[13px]">
            <span className="inline-flex items-center gap-1.5 text-ink/55">
              <MapPin className="size-3.5" />
              {nurse.city}
            </span>
            <span className="font-semibold text-ink">
              {nurse.pricePerVisit} MAD
              <span className="font-normal text-ink/45"> / visite</span>
            </span>
          </div>
        </div>
      </Link>
    </Reveal>
  );
}

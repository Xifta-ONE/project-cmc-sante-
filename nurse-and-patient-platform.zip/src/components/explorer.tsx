"use client";

import { useMemo, useState } from "react";
import { motion } from "framer-motion";
import { ChevronDown, RotateCcw, Search, SlidersHorizontal } from "lucide-react";
import type { Nurse } from "@/db/schema";
import { EASE, Eyebrow, NurseCard } from "@/components/site";

type SortKey = "rating" | "prix-asc" | "prix-desc" | "experience";

const SORTS: { key: SortKey; label: string }[] = [
  { key: "rating", label: "Meilleures notes" },
  { key: "prix-asc", label: "Prix croissant" },
  { key: "prix-desc", label: "Prix décroissant" },
  { key: "experience", label: "Expérience" },
];

export function Explorer({
  nurses,
  cities,
  specialties,
  initialVille = "",
}: {
  nurses: Nurse[];
  cities: string[];
  specialties: string[];
  initialVille?: string;
}) {
  const [query, setQuery] = useState("");
  const [ville, setVille] = useState(initialVille);
  const [specialty, setSpecialty] = useState("");
  const [sort, setSort] = useState<SortKey>("rating");

  const filtered = useMemo(() => {
    let list = [...nurses];
    if (ville) list = list.filter((n) => n.city === ville);
    if (specialty) list = list.filter((n) => n.specialty === specialty);
    if (query.trim()) {
      const q = query.trim().toLowerCase();
      list = list.filter(
        (n) =>
          n.name.toLowerCase().includes(q) ||
          n.specialty.toLowerCase().includes(q) ||
          n.city.toLowerCase().includes(q),
      );
    }
    switch (sort) {
      case "prix-asc":
        list.sort((a, b) => a.pricePerVisit - b.pricePerVisit);
        break;
      case "prix-desc":
        list.sort((a, b) => b.pricePerVisit - a.pricePerVisit);
        break;
      case "experience":
        list.sort((a, b) => b.yearsExperience - a.yearsExperience);
        break;
      default:
        list.sort((a, b) => b.rating - a.rating);
    }
    return list;
  }, [nurses, query, ville, specialty, sort]);

  const hasFilters = query || ville || specialty;

  return (
    <section className="pb-24 pt-32 md:pt-40">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, ease: EASE }}
          className="max-w-2xl"
        >
          <Eyebrow>Réseau d&apos;infirmiers vérifiés</Eyebrow>
          <h1 className="mt-6 font-display text-5xl font-medium leading-[0.98] tracking-tight text-ink md:text-7xl">
            Trouvez votre{" "}
            <em className="font-light text-apricot">infirmier.</em>
          </h1>
          <p className="mt-6 leading-relaxed text-ink/60">
            Filtrez par ville, spécialité ou budget. Chaque profil est vérifié :
            diplôme d&apos;État, expérience et avis patients contrôlés.
          </p>
        </motion.div>

        {/* filter bar */}
        <motion.div
          initial={{ opacity: 0, y: 24 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.8, delay: 0.15, ease: EASE }}
          className="sticky top-20 z-30 mt-12 rounded-[2rem] border border-ink/10 bg-paper/90 p-3 shadow-xl shadow-ink/5 backdrop-blur-xl"
        >
          <div className="grid gap-2 md:grid-cols-[1.4fr_1fr_1fr_1fr]">
            <label className="flex items-center gap-3 rounded-2xl bg-mint-soft px-5 py-3.5">
              <Search className="size-4 shrink-0 text-moss" />
              <input
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="Nom, spécialité, ville…"
                className="w-full bg-transparent text-sm text-ink outline-none placeholder:text-ink/40"
              />
            </label>
            <label className="relative flex items-center rounded-2xl bg-mint-soft px-5 py-3.5">
              <select
                value={ville}
                onChange={(e) => setVille(e.target.value)}
                className="w-full appearance-none bg-transparent text-sm text-ink outline-none"
              >
                <option value="">Toutes les villes</option>
                {cities.map((c) => (
                  <option key={c} value={c}>
                    {c}
                  </option>
                ))}
              </select>
              <ChevronDown className="pointer-events-none absolute right-5 size-4 text-moss" />
            </label>
            <label className="relative flex items-center rounded-2xl bg-mint-soft px-5 py-3.5">
              <select
                value={specialty}
                onChange={(e) => setSpecialty(e.target.value)}
                className="w-full appearance-none bg-transparent text-sm text-ink outline-none"
              >
                <option value="">Toutes spécialités</option>
                {specialties.map((s) => (
                  <option key={s} value={s}>
                    {s}
                  </option>
                ))}
              </select>
              <ChevronDown className="pointer-events-none absolute right-5 size-4 text-moss" />
            </label>
            <label className="relative flex items-center rounded-2xl bg-ink px-5 py-3.5 text-paper">
              <SlidersHorizontal className="mr-2 size-4 shrink-0 text-apricot" />
              <select
                value={sort}
                onChange={(e) => setSort(e.target.value as SortKey)}
                className="w-full appearance-none bg-transparent text-sm outline-none [&>option]:text-ink"
              >
                {SORTS.map((s) => (
                  <option key={s.key} value={s.key}>
                    {s.label}
                  </option>
                ))}
              </select>
              <ChevronDown className="pointer-events-none absolute right-5 size-4 text-paper/70" />
            </label>
          </div>
        </motion.div>

        {/* results */}
        <div className="mt-8 flex items-center justify-between">
          <p className="font-mono text-[11px] uppercase tracking-[0.18em] text-ink/50">
            {filtered.length} infirmier{filtered.length > 1 ? "s" : ""} disponible
            {filtered.length > 1 ? "s" : ""}
          </p>
          {hasFilters && (
            <button
              onClick={() => {
                setQuery("");
                setVille("");
                setSpecialty("");
              }}
              className="inline-flex items-center gap-2 font-mono text-[11px] uppercase tracking-[0.16em] text-apricot-deep transition-colors hover:text-apricot"
            >
              <RotateCcw className="size-3.5" />
              Réinitialiser
            </button>
          )}
        </div>

        {filtered.length > 0 ? (
          <div className="mt-6 grid gap-5 sm:grid-cols-2 lg:grid-cols-4">
            {filtered.map((n, i) => (
              <NurseCard key={n.id} nurse={n} index={i} />
            ))}
          </div>
        ) : (
          <div className="mt-6 grid place-items-center rounded-[2rem] border border-dashed border-ink/20 bg-paper/60 px-6 py-24 text-center">
            <p className="font-display text-3xl text-ink">Aucun résultat</p>
            <p className="mt-3 max-w-sm text-sm text-ink/55">
              Essayez d&apos;élargir votre recherche ou de retirer certains
              filtres — de nouveaux infirmiers nous rejoignent chaque semaine.
            </p>
          </div>
        )}
      </div>
    </section>
  );
}

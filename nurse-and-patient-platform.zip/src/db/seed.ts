import "dotenv/config";
import { db } from "./index";
import { bookings, nurses, reviews, services } from "./schema";

function daysFromNow(days: number) {
  return new Date(Date.now() + days * 86_400_000).toISOString().slice(0, 10);
}

async function main() {
  console.log("Seeding Shifa database...");

  await db.delete(bookings);
  await db.delete(reviews);
  await db.delete(nurses);
  await db.delete(services);

  const insertedNurses = await db
    .insert(nurses)
    .values([
      {
        slug: "yasmine-el-fassi",
        name: "Yasmine El Fassi",
        title: "Infirmière diplômée d'État",
        specialty: "Soins post-opératoires",
        city: "Casablanca",
        photo:
          "https://images.pexels.com/photos/5430213/pexels-photo-5430213.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
        rating: 4.9,
        reviewsCount: 214,
        visitsCount: 1450,
        yearsExperience: 8,
        pricePerVisit: 200,
        languages: ["Français", "Arabe", "Anglais"],
        verified: true,
        availableToday: true,
        bio: "Spécialiste des suites opératoires, Yasmine accompagne chaque patient avec rigueur et douceur : surveillance, cicatrisation, ablation de fils et éducation thérapeutique, directement à votre domicile.",
      },
      {
        slug: "karim-benali",
        name: "Karim Benali",
        title: "Infirmier diplômé d'État",
        specialty: "Injections & perfusions",
        city: "Rabat",
        photo:
          "https://images.pexels.com/photos/6303564/pexels-photo-6303564.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
        rating: 4.8,
        reviewsCount: 189,
        visitsCount: 2100,
        yearsExperience: 11,
        pricePerVisit: 180,
        languages: ["Français", "Arabe"],
        verified: true,
        availableToday: true,
        bio: "Onze années de pratique hospitalière et à domicile. Karim réalise injections, vaccinations et perfusions (antibiotiques, hydratation, fer injectable) dans le respect strict des protocoles — et toujours avec le sourire.",
      },
      {
        slug: "sofia-amrani",
        name: "Sofia Amrani",
        title: "Infirmière spécialisée en diabétologie",
        specialty: "Soins diabétiques",
        city: "Marrakech",
        photo:
          "https://images.pexels.com/photos/39556774/pexels-photo-39556774.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
        rating: 5.0,
        reviewsCount: 96,
        visitsCount: 780,
        yearsExperience: 6,
        pricePerVisit: 190,
        languages: ["Français", "Arabe"],
        verified: true,
        availableToday: false,
        bio: "Contrôle glycémique, injection d'insuline, surveillance des pieds et éducation du patient : Sofia construit avec chaque famille un suivi diabétique simple, régulier et rassurant.",
      },
      {
        slug: "mehdi-tazi",
        name: "Mehdi Tazi",
        title: "Infirmier plaies & cicatrisation",
        specialty: "Pansements & plaies",
        city: "Casablanca",
        photo:
          "https://images.pexels.com/photos/32254526/pexels-photo-32254526.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
        rating: 4.7,
        reviewsCount: 152,
        visitsCount: 1230,
        yearsExperience: 9,
        pricePerVisit: 170,
        languages: ["Français", "Arabe"],
        verified: true,
        availableToday: true,
        bio: "Ulcères, escarres, plaies chroniques ou pansements complexes : Mehdi maîtrise les protocoles de cicatrisation les plus exigeants et suit l'évolution de chaque plaie avec précision.",
      },
      {
        slug: "nadia-berrada",
        name: "Nadia Berrada",
        title: "Infirmière — soins palliatifs",
        specialty: "Soins palliatifs",
        city: "Tanger",
        photo:
          "https://images.pexels.com/photos/6129496/pexels-photo-6129496.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
        rating: 4.9,
        reviewsCount: 167,
        visitsCount: 2600,
        yearsExperience: 14,
        pricePerVisit: 260,
        languages: ["Français", "Arabe"],
        verified: true,
        availableToday: false,
        bio: "Quatorze ans d'expérience au service du confort et de la dignité. Nadia coordonne la gestion de la douleur, les soins de confort et le soutien des proches, avec une écoute rare.",
      },
      {
        slug: "omar-chraibi",
        name: "Omar Chraibi",
        title: "Infirmier polyvalent",
        specialty: "Soins généraux",
        city: "Fès",
        photo:
          "https://images.pexels.com/photos/4270371/pexels-photo-4270371.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
        rating: 4.8,
        reviewsCount: 88,
        visitsCount: 640,
        yearsExperience: 5,
        pricePerVisit: 150,
        languages: ["Français", "Arabe", "Anglais"],
        verified: true,
        availableToday: true,
        bio: "Prises de sang, surveillances, injections, petits soins du quotidien : Omar intervient 7 jours sur 7 sur Fès et sa région, y compris le soir et le week-end.",
      },
      {
        slug: "salma-idrissi",
        name: "Salma Idrissi",
        title: "Infirmière périnatalité",
        specialty: "Maternité & nouveau-né",
        city: "Rabat",
        photo:
          "https://images.pexels.com/photos/5206931/pexels-photo-5206931.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
        rating: 4.9,
        reviewsCount: 121,
        visitsCount: 890,
        yearsExperience: 7,
        pricePerVisit: 220,
        languages: ["Français", "Arabe"],
        verified: true,
        availableToday: true,
        bio: "Suites de couches, soutien à l'allaitement, pesée et toilette du nouveau-né : Salma accompagne les jeunes mamans pour un retour à la maison serein, en lien direct avec leur maternité.",
      },
      {
        slug: "ayoub-el-mansouri",
        name: "Ayoub El Mansouri",
        title: "Infirmier gériatrie",
        specialty: "Soins seniors",
        city: "Agadir",
        photo:
          "https://images.pexels.com/photos/6303777/pexels-photo-6303777.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=1200&w=800",
        rating: 4.6,
        reviewsCount: 74,
        visitsCount: 520,
        yearsExperience: 4,
        pricePerVisit: 150,
        languages: ["Français", "Arabe"],
        verified: true,
        availableToday: false,
        bio: "Toilette, aide à la mobilité, prévention des chutes et surveillance médicale des personnes âgées : Ayoub visite vos aînés avec patience, humour et ponctualité.",
      },
    ])
    .returning();

  const N = Object.fromEntries(insertedNurses.map((n) => [n.slug, n.id]));

  await db.insert(services).values([
    {
      slug: "injection",
      name: "Injection & vaccination",
      description:
        "Injections intramusculaires et sous-cutanées, vaccinations, sur prescription médicale.",
      icon: "Syringe",
      priceFrom: 100,
      durationMin: 20,
    },
    {
      slug: "perfusion",
      name: "Perfusion à domicile",
      description:
        "Pose, surveillance et retrait de perfusions : antibiothérapie, hydratation, fer injectable.",
      icon: "Droplets",
      priceFrom: 250,
      durationMin: 90,
    },
    {
      slug: "pansement",
      name: "Pansements & plaies",
      description:
        "Pansements simples et complexes, plaies chroniques, ulcères et escarres, suivi de cicatrisation.",
      icon: "Bandage",
      priceFrom: 150,
      durationMin: 45,
    },
    {
      slug: "post-op",
      name: "Soins post-opératoires",
      description:
        "Surveillance après intervention, ablation de fils ou d'agrafes, contrôle de la douleur.",
      icon: "Stethoscope",
      priceFrom: 200,
      durationMin: 60,
    },
    {
      slug: "diabete",
      name: "Suivi diabétique",
      description:
        "Contrôle de la glycémie, injection d'insuline, éducation et accompagnement au quotidien.",
      icon: "Activity",
      priceFrom: 180,
      durationMin: 45,
    },
    {
      slug: "palliatif",
      name: "Soins palliatifs",
      description:
        "Soins de confort, gestion de la douleur et accompagnement du patient et de sa famille.",
      icon: "HeartHandshake",
      priceFrom: 300,
      durationMin: 120,
    },
    {
      slug: "maternite",
      name: "Maman & nouveau-né",
      description:
        "Suites de couches, soutien à l'allaitement, toilette et pesée du nouveau-né.",
      icon: "Baby",
      priceFrom: 220,
      durationMin: 60,
    },
    {
      slug: "hygiene",
      name: "Toilette & aide au quotidien",
      description:
        "Toilette complète, aide à la mobilité et accompagnement des personnes âgées à domicile.",
      icon: "ShowerHead",
      priceFrom: 160,
      durationMin: 60,
    },
  ]);

  await db.insert(reviews).values([
    { nurseId: N["yasmine-el-fassi"], patientName: "Fatima Z.", rating: 5, comment: "Retour d'opération délicat, Yasmine a tout rendu simple. Ponctuelle, délicate, très professionnelle." },
    { nurseId: N["yasmine-el-fassi"], patientName: "Youssef B.", rating: 5, comment: "Une rigueur rassurante du premier au dernier pansement. Je recommande vivement." },
    { nurseId: N["karim-benali"], patientName: "Amina R.", rating: 5, comment: "Perfusion à domicile impeccable, zéro stress. Tout était prêt, propre et expliqué." },
    { nurseId: N["karim-benali"], patientName: "Sara T.", rating: 5, comment: "Piqûres indolores — ma fille ne craint plus les injections. Merci Karim !" },
    { nurseId: N["karim-benali"], patientName: "Hassan M.", rating: 4, comment: "Très professionnel, il explique chaque geste. Petit retard un soir, mais prévenu à l'avance." },
    { nurseId: N["sofia-amrani"], patientName: "Salma K.", rating: 5, comment: "Ma mère diabétique est enfin suivie correctement. Ses conseils ont changé notre quotidien." },
    { nurseId: N["sofia-amrani"], patientName: "Naïma D.", rating: 5, comment: "Très pédagogue sur l'insuline, patiente avec mes questions. Une perle." },
    { nurseId: N["mehdi-tazi"], patientName: "Driss L.", rating: 5, comment: "Un pansement complexe traité avec un soin remarquable. La plaie a enfin fermé." },
    { nurseId: N["mehdi-tazi"], patientName: "Khadija A.", rating: 4, comment: "Gentil, méthodique et efficace. Matériel impeccable." },
    { nurseId: N["nadia-berrada"], patientName: "Famille Bennis", rating: 5, comment: "Dans un moment très difficile, Nadia a été d'une humanité extraordinaire. Nous ne l'oublierons jamais." },
    { nurseId: N["nadia-berrada"], patientName: "Leïla G.", rating: 5, comment: "Accompagnement digne et respectueux de mon père jusqu'au bout. Merci infiniment." },
    { nurseId: N["omar-chraibi"], patientName: "Anas E.", rating: 5, comment: "Rapide et disponible un dimanche soir pour une prise de sang urgente. Impeccable." },
    { nurseId: N["salma-idrissi"], patientName: "Meriem F.", rating: 5, comment: "Suivi post-accouchement au top, conseils précieux pour bébé et pour moi." },
    { nurseId: N["ayoub-el-mansouri"], patientName: "Rachid B.", rating: 5, comment: "Mon père l'adore. Patience, bonne humeur et vraie compétence à chaque visite." },
  ]);

  const slot = ["08:00 – 10:00", "10:00 – 12:00", "14:00 – 16:00", "16:00 – 18:00", "18:00 – 20:00"];

  await db.insert(bookings).values([
    {
      reference: "SH-7K2P4N",
      nurseId: N["yasmine-el-fassi"],
      serviceName: "Soins post-opératoires",
      patientName: "Mohammed Alami",
      patientPhone: "+212661234567",
      date: daysFromNow(1),
      timeSlot: slot[3],
      address: "12, rue des Jardins, Quartier Racine",
      city: "Casablanca",
      notes: "Ablation de fils après chirurgie du genou. Ordonnance disponible.",
      status: "confirmed",
    },
    {
      reference: "SH-3M9Q2X",
      nurseId: N["yasmine-el-fassi"],
      serviceName: "Pansements & plaies",
      patientName: "Mohammed Alami",
      patientPhone: "+212661234567",
      date: daysFromNow(-6),
      timeSlot: slot[1],
      address: "12, rue des Jardins, Quartier Racine",
      city: "Casablanca",
      notes: null,
      status: "completed",
    },
    {
      reference: "SH-8T4W7B",
      nurseId: N["karim-benali"],
      serviceName: "Perfusion à domicile",
      patientName: "Zineb Ouazzani",
      patientPhone: "+212661234567",
      date: daysFromNow(2),
      timeSlot: slot[0],
      address: "45, avenue Hassan II, Agdal",
      city: "Rabat",
      notes: "Antibiothérapie jour 3/7.",
      status: "pending",
    },
    {
      reference: "SH-2C6V9D",
      nurseId: N["sofia-amrani"],
      serviceName: "Suivi diabétique",
      patientName: "Lalla Aicha",
      patientPhone: "+212655443322",
      date: daysFromNow(1),
      timeSlot: slot[2],
      address: "Villa 18, route de l'Ourika",
      city: "Marrakech",
      notes: "Patient de 72 ans, insuline matin et soir.",
      status: "confirmed",
    },
    {
      reference: "SH-5F1H3J",
      nurseId: N["mehdi-tazi"],
      serviceName: "Pansements & plaies",
      patientName: "Khalid Bennani",
      patientPhone: "+212662009988",
      date: daysFromNow(0),
      timeSlot: slot[4],
      address: "Rés. Les Orangers, apt 34, Maârif",
      city: "Casablanca",
      notes: "Escarre talon droit.",
      status: "pending",
    },
    {
      reference: "SH-9L8Z5R",
      nurseId: N["nadia-berrada"],
      serviceName: "Soins palliatifs",
      patientName: "Famille Tahiri",
      patientPhone: "+212661112233",
      date: daysFromNow(0),
      timeSlot: slot[2],
      address: "23, rue de la Plage, Malabata",
      city: "Tanger",
      notes: "Visite quotidienne souhaitée à 14h.",
      status: "confirmed",
    },
    {
      reference: "SH-4G7Y1K",
      nurseId: N["omar-chraibi"],
      serviceName: "Injection & vaccination",
      patientName: "Salim El Khattabi",
      patientPhone: "+212661122334",
      date: daysFromNow(-2),
      timeSlot: slot[1],
      address: "8, derb Sidi Boulfdail, Fès el-Bali",
      city: "Fès",
      notes: null,
      status: "completed",
    },
    {
      reference: "SH-6B3N8M",
      nurseId: N["salma-idrissi"],
      serviceName: "Maman & nouveau-né",
      patientName: "Imane Chafik",
      patientPhone: "+212662334455",
      date: daysFromNow(3),
      timeSlot: slot[0],
      address: "Lot Firdaous, villa 9, Hay Riad",
      city: "Rabat",
      notes: "Jumeaux, 12 jours. Allaitement mixte.",
      status: "pending",
    },
    {
      reference: "SH-1Q5D2P",
      nurseId: N["ayoub-el-mansouri"],
      serviceName: "Toilette & aide au quotidien",
      patientName: "Hadj Omar",
      patientPhone: "+212665556677",
      date: daysFromNow(1),
      timeSlot: slot[0],
      address: "14, cité Suisse, secteur 3",
      city: "Agadir",
      notes: null,
      status: "pending",
    },
    {
      reference: "SH-0A9S4E",
      nurseId: N["mehdi-tazi"],
      serviceName: "Soins post-opératoires",
      patientName: "Nisrine El Idrissi",
      patientPhone: "+212663322110",
      date: daysFromNow(-10),
      timeSlot: slot[3],
      address: "Bd Anfa, rés. Le Panoramique",
      city: "Casablanca",
      notes: "Annulé par le patient.",
      status: "cancelled",
    },
  ]);

  console.log("Seed complete:", {
    nurses: insertedNurses.length,
    services: 8,
    reviews: 14,
    bookings: 10,
  });
}

main()
  .then(() => process.exit(0))
  .catch((err) => {
    console.error(err);
    process.exit(1);
  });

import {
  boolean,
  integer,
  jsonb,
  pgEnum,
  pgTable,
  real,
  serial,
  text,
  timestamp,
  varchar,
} from "drizzle-orm/pg-core";

export const bookingStatus = pgEnum("booking_status", [
  "pending",
  "confirmed",
  "completed",
  "cancelled",
]);

export const nurses = pgTable("nurses", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 120 }).notNull().unique(),
  name: varchar("name", { length: 120 }).notNull(),
  title: varchar("title", { length: 160 }).notNull(),
  specialty: varchar("specialty", { length: 120 }).notNull(),
  city: varchar("city", { length: 80 }).notNull(),
  bio: text("bio").notNull(),
  photo: text("photo").notNull(),
  rating: real("rating").notNull().default(5),
  reviewsCount: integer("reviews_count").notNull().default(0),
  visitsCount: integer("visits_count").notNull().default(0),
  yearsExperience: integer("years_experience").notNull(),
  pricePerVisit: integer("price_per_visit").notNull(),
  languages: jsonb("languages").$type<string[]>().notNull().default([]),
  verified: boolean("verified").notNull().default(true),
  availableToday: boolean("available_today").notNull().default(false),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const services = pgTable("services", {
  id: serial("id").primaryKey(),
  slug: varchar("slug", { length: 120 }).notNull().unique(),
  name: varchar("name", { length: 120 }).notNull(),
  description: text("description").notNull(),
  icon: varchar("icon", { length: 60 }).notNull(),
  priceFrom: integer("price_from").notNull(),
  durationMin: integer("duration_min").notNull(),
});

export const bookings = pgTable("bookings", {
  id: serial("id").primaryKey(),
  reference: varchar("reference", { length: 24 }).notNull().unique(),
  nurseId: integer("nurse_id")
    .notNull()
    .references(() => nurses.id),
  serviceName: varchar("service_name", { length: 120 }).notNull(),
  patientName: varchar("patient_name", { length: 120 }).notNull(),
  patientPhone: varchar("patient_phone", { length: 30 }).notNull(),
  date: varchar("date", { length: 20 }).notNull(),
  timeSlot: varchar("time_slot", { length: 40 }).notNull(),
  address: text("address").notNull(),
  city: varchar("city", { length: 80 }).notNull(),
  notes: text("notes"),
  status: bookingStatus("status").notNull().default("pending"),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export const reviews = pgTable("reviews", {
  id: serial("id").primaryKey(),
  nurseId: integer("nurse_id")
    .notNull()
    .references(() => nurses.id),
  patientName: varchar("patient_name", { length: 120 }).notNull(),
  rating: integer("rating").notNull(),
  comment: text("comment").notNull(),
  createdAt: timestamp("created_at", { withTimezone: true })
    .notNull()
    .defaultNow(),
});

export type Nurse = typeof nurses.$inferSelect;
export type Service = typeof services.$inferSelect;
export type Booking = typeof bookings.$inferSelect;
export type Review = typeof reviews.$inferSelect;

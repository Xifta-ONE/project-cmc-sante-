import { desc } from "drizzle-orm";
import { db } from "@/db";
import { nurses, services } from "@/db/schema";
import {
  Cities,
  CtaSection,
  FeaturedNurses,
  Hero,
  HowItWorks,
  Marquee,
  ServicesSection,
  Stats,
  Testimonials,
} from "@/components/landing";

export const dynamic = "force-dynamic";

export default async function HomePage() {
  const [allServices, topNurses, allNurses] = await Promise.all([
    db.select().from(services).orderBy(services.priceFrom),
    db.select().from(nurses).orderBy(desc(nurses.rating)).limit(4),
    db.select().from(nurses),
  ]);

  return (
    <main>
      <Hero nurses={topNurses.length ? topNurses : allNurses} />
      <Marquee services={allServices} />
      <Stats />
      <ServicesSection services={allServices} />
      <FeaturedNurses nurses={topNurses} />
      <HowItWorks />
      <Testimonials />
      <Cities nurses={allNurses} />
      <CtaSection />
    </main>
  );
}

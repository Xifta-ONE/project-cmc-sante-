import type { Metadata } from "next";
import { NurseSpace } from "@/components/nurse-space";

export const metadata: Metadata = {
  title: "Espace infirmier — Shifa",
  description:
    "Gérez vos demandes de visite à domicile : confirmez vos créneaux, organisez vos tournées et suivez vos soins réalisés.",
};

export default function EspaceInfirmierPage() {
  return (
    <main>
      <NurseSpace />
    </main>
  );
}

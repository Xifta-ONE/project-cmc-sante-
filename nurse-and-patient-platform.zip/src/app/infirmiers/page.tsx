import type { Metadata } from "next";
import { db } from "@/db";
import { nurses } from "@/db/schema";
import { Explorer } from "@/components/explorer";

export const dynamic = "force-dynamic";

export const metadata: Metadata = {
  title: "Trouver un infirmier — Shifa",
  description:
    "Parcourez notre réseau d'infirmiers diplômés et vérifiés. Filtrez par ville, spécialité et budget, puis réservez votre visite à domicile.",
};

export default async function InfirmiersPage({
  searchParams,
}: {
  searchParams: Promise<{ ville?: string; soin?: string }>;
}) {
  const all = await db.select().from(nurses);
  const { ville, soin } = await searchParams;

  const cities = [...new Set(all.map((n) => n.city))].sort();
  const specialties = [...new Set(all.map((n) => n.specialty))].sort();

  const initialVille =
    ville && cities.includes(ville)
      ? ville
      : soin && cities.includes(soin)
        ? soin
        : "";

  return (
    <main>
      <Explorer
        nurses={all}
        cities={cities}
        specialties={specialties}
        initialVille={initialVille}
      />
    </main>
  );
}

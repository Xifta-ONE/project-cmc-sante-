import type { Metadata } from "next";
import Link from "next/link";
import { notFound } from "next/navigation";
import { asc, desc, eq } from "drizzle-orm";
import {
  ArrowLeft,
  BadgeCheck,
  Briefcase,
  Clock,
  Globe2,
  HandHeart,
  MapPin,
  Quote,
} from "lucide-react";
import { db } from "@/db";
import { nurses, reviews, services } from "@/db/schema";
import { Eyebrow, Reveal, Stars } from "@/components/site";
import { BookingForm } from "@/components/booking-form";

export const dynamic = "force-dynamic";

export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const [nurse] = await db.select().from(nurses).where(eq(nurses.slug, slug));
  if (!nurse) return { title: "Infirmier introuvable — Shifa" };
  return {
    title: `${nurse.name} — ${nurse.specialty} à ${nurse.city} | Shifa`,
    description: nurse.bio,
  };
}

export default async function NurseProfilePage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const [nurse] = await db.select().from(nurses).where(eq(nurses.slug, slug));
  if (!nurse) notFound();

  const [nurseReviews, allServices] = await Promise.all([
    db
      .select()
      .from(reviews)
      .where(eq(reviews.nurseId, nurse.id))
      .orderBy(desc(reviews.createdAt)),
    db.select().from(services).orderBy(asc(services.priceFrom)),
  ]);

  const facts = [
    { icon: Briefcase, label: "Expérience", value: `${nurse.yearsExperience} ans` },
    { icon: HandHeart, label: "Visites réalisées", value: nurse.visitsCount.toLocaleString("fr-FR") },
    { icon: MapPin, label: "Zone d'intervention", value: nurse.city },
    { icon: Globe2, label: "Langues", value: nurse.languages.join(" · ") },
  ];

  return (
    <main className="pb-24 pt-28 md:pt-36">
      <div className="mx-auto max-w-7xl px-5 md:px-8">
        <Reveal>
          <Link
            href="/infirmiers"
            className="inline-flex items-center gap-2 font-mono text-[11px] uppercase tracking-[0.16em] text-ink/50 transition-colors hover:text-ink"
          >
            <ArrowLeft className="size-3.5" />
            Tous les infirmiers
          </Link>
        </Reveal>

        <div className="mt-8 grid gap-12 lg:grid-cols-12">
          {/* --------------------------------- left : profile -------------------------------- */}
          <div className="lg:col-span-7">
            <Reveal>
              <div className="flex flex-wrap items-center gap-3">
                <span className="rounded-full bg-mint px-4 py-1.5 font-mono text-[10px] uppercase tracking-[0.16em] text-pine">
                  {nurse.specialty}
                </span>
                {nurse.availableToday && (
                  <span className="inline-flex items-center gap-1.5 rounded-full bg-pine px-4 py-1.5 font-mono text-[10px] uppercase tracking-[0.16em] text-paper">
                    <span className="animate-pulse-soft size-1.5 rounded-full bg-emerald-300" />
                    Disponible aujourd&apos;hui
                  </span>
                )}
              </div>
              <h1 className="mt-5 flex flex-wrap items-center gap-3 font-display text-5xl font-medium leading-[0.98] tracking-tight text-ink md:text-7xl">
                {nurse.name}
                {nurse.verified && (
                  <span className="grid size-11 place-items-center rounded-full bg-apricot text-paper shadow-lg shadow-apricot/25 md:size-14">
                    <BadgeCheck className="size-6 md:size-7" />
                  </span>
                )}
              </h1>
              <p className="mt-3 font-display text-xl italic text-ink/55">
                {nurse.title}
              </p>
              <div className="mt-5 flex flex-wrap items-center gap-5 text-sm text-ink/60">
                <span className="flex items-center gap-2">
                  <Stars rating={nurse.rating} />
                  <strong className="text-ink">{nurse.rating.toFixed(1)}</strong>
                  <span>({nurse.reviewsCount} avis)</span>
                </span>
                <span className="flex items-center gap-1.5">
                  <MapPin className="size-4 text-apricot" />
                  {nurse.city}
                </span>
              </div>
            </Reveal>

            <Reveal delay={0.1}>
              <div className="mt-9 grid grid-cols-2 gap-px overflow-hidden rounded-[2rem] border border-ink/8 bg-ink/8 md:grid-cols-4">
                {facts.map((f) => (
                  <div key={f.label} className="bg-paper p-5">
                    <f.icon className="size-4 text-moss" strokeWidth={1.8} />
                    <p className="mt-3 font-mono text-[10px] uppercase tracking-[0.14em] text-ink/45">
                      {f.label}
                    </p>
                    <p className="mt-1.5 text-[15px] font-semibold leading-snug text-ink">
                      {f.value}
                    </p>
                  </div>
                ))}
              </div>
            </Reveal>

            <Reveal delay={0.15}>
              <p className="mt-9 max-w-2xl text-lg leading-relaxed text-ink/70">
                {nurse.bio}
              </p>
            </Reveal>

            {/* acts & rates */}
            <Reveal delay={0.2}>
              <div className="mt-14">
                <Eyebrow>Actes & tarifs</Eyebrow>
                <div className="mt-6 overflow-hidden rounded-[2rem] border border-ink/8">
                  <div className="flex items-center justify-between bg-pine px-6 py-4 text-paper">
                    <span className="font-mono text-[10px] uppercase tracking-[0.18em]">
                      Visite à domicile
                    </span>
                    <span className="font-display text-2xl font-medium">
                      {nurse.pricePerVisit} MAD
                    </span>
                  </div>
                  {allServices.map((s, i) => (
                    <div
                      key={s.id}
                      className={`flex items-center justify-between gap-4 px-6 py-4 ${
                        i % 2 === 0 ? "bg-paper" : "bg-mint-soft/60"
                      }`}
                    >
                      <div className="flex items-center gap-4">
                        <span className="grid size-9 shrink-0 place-items-center rounded-xl bg-mint text-pine">
                          <Clock className="hidden" />
                          <HandHeart className="size-4" strokeWidth={1.8} />
                        </span>
                        <div>
                          <p className="text-sm font-semibold text-ink">{s.name}</p>
                          <p className="text-xs text-ink/50">
                            ~{s.durationMin} min
                          </p>
                        </div>
                      </div>
                      <span className="whitespace-nowrap font-mono text-[11px] uppercase tracking-[0.12em] text-ink/60">
                        dès {Math.round((s.priceFrom + nurse.pricePerVisit) / 2)} MAD
                      </span>
                    </div>
                  ))}
                </div>
                <p className="mt-3 text-xs text-ink/45">
                  Tarifs indicifs — le montant exact est confirmé par
                  l&apos;infirmier avant la visite. Paiement sur place.
                </p>
              </div>
            </Reveal>

            {/* reviews */}
            <Reveal delay={0.22}>
              <div className="mt-14">
                <Eyebrow>Avis des patients</Eyebrow>
                <div className="mt-6 grid gap-4 md:grid-cols-2">
                  {nurseReviews.length === 0 && (
                    <p className="col-span-2 rounded-3xl border border-dashed border-ink/20 p-8 text-center text-sm text-ink/50">
                      Aucun avis pour le moment — soyez le premier patient à en
                      laisser un.
                    </p>
                  )}
                  {nurseReviews.map((r) => (
                    <div
                      key={r.id}
                      className="rounded-[1.75rem] border border-ink/8 bg-paper p-6"
                    >
                      <Quote className="size-5 text-apricot" />
                      <p className="mt-4 text-[14px] leading-relaxed text-ink/70">
                        {r.comment}
                      </p>
                      <div className="mt-5 flex items-center justify-between">
                        <div>
                          <p className="text-sm font-semibold text-ink">
                            {r.patientName}
                          </p>
                          <p className="font-mono text-[10px] uppercase tracking-[0.14em] text-ink/40">
                            {new Date(r.createdAt).toLocaleDateString("fr-FR", {
                              month: "long",
                              year: "numeric",
                            })}
                          </p>
                        </div>
                        <Stars rating={r.rating} />
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </Reveal>
          </div>

          {/* -------------------------------- right : sticky booking ------------------------------- */}
          <div className="lg:col-span-5">
            <div className="lg:sticky lg:top-28">
              <Reveal delay={0.15}>
                <div className="overflow-hidden rounded-[2.25rem] border border-ink/10 bg-paper shadow-2xl shadow-pine/10">
                  <div className="relative">
                    <img
                      src={nurse.photo}
                      alt={`Portrait de ${nurse.name}`}
                      className="aspect-[16/9] w-full object-cover object-top"
                    />
                    <div className="absolute inset-0 bg-gradient-to-t from-pine-deep/70 via-transparent to-transparent" />
                    <div className="absolute bottom-4 left-5 right-5 flex items-end justify-between text-paper">
                      <div>
                        <p className="font-mono text-[10px] uppercase tracking-[0.16em] text-paper/70">
                          Réserver une visite avec
                        </p>
                        <p className="font-display text-2xl font-medium">
                          {nurse.name.split(" ")[0]}
                        </p>
                      </div>
                      <p className="text-right">
                        <span className="font-display text-3xl font-medium">
                          {nurse.pricePerVisit}
                        </span>
                        <span className="ml-1 font-mono text-[10px] uppercase tracking-[0.12em]">
                          MAD
                        </span>
                      </p>
                    </div>
                  </div>
                  <div className="p-6 md:p-7">
                    <BookingForm
                      nurseId={nurse.id}
                      nurseName={nurse.name}
                      nurseCity={nurse.city}
                      services={allServices.map((s) => ({
                        id: s.id,
                        name: s.name,
                        priceFrom: s.priceFrom,
                      }))}
                    />
                  </div>
                </div>
              </Reveal>
              <Reveal delay={0.22}>
                <div className="mt-4 flex items-center justify-center gap-2 rounded-full border border-ink/10 bg-paper/70 px-5 py-3 font-mono text-[10px] uppercase tracking-[0.14em] text-ink/50">
                  <BadgeCheck className="size-4 text-moss" />
                  Annulation gratuite jusqu&apos;à 2h avant · Paiement sur place
                </div>
              </Reveal>
            </div>
          </div>
        </div>
      </div>
    </main>
  );
}

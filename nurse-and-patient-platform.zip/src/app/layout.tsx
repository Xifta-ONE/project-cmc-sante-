import type { Metadata } from "next";
import type { ReactNode } from "react";
import "./globals.css";
import { Navbar, Footer } from "@/components/site";

export const metadata: Metadata = {
  title: "Shifa — Soins infirmiers à domicile",
  description:
    "Shifa met en relation patients et infirmiers diplômés pour des soins à domicile : injections, perfusions, pansements, suivi post-opératoire. Partout au Maroc, en quelques clics.",
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="fr">
      <head>
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link
          rel="preconnect"
          href="https://fonts.gstatic.com"
          crossOrigin="anonymous"
        />
        <link
          href="https://fonts.googleapis.com/css2?family=Fraunces:ital,opsz,wght@0,9..144,300..700;1,9..144,300..700&family=IBM+Plex+Mono:wght@400;500&family=Inter:wght@400;500;600;700&display=swap"
          rel="stylesheet"
        />
      </head>
      <body className="grain bg-cream font-sans text-ink">
        <Navbar />
        {children}
        <Footer />
      </body>
    </html>
  );
}

import { NextResponse } from "next/server";
import { desc, eq, sql } from "drizzle-orm";
import { db } from "@/db";
import { bookings, nurses } from "@/db/schema";

export const dynamic = "force-dynamic";

const bookingWithNurse = {
  id: bookings.id,
  reference: bookings.reference,
  nurseId: bookings.nurseId,
  serviceName: bookings.serviceName,
  patientName: bookings.patientName,
  patientPhone: bookings.patientPhone,
  date: bookings.date,
  timeSlot: bookings.timeSlot,
  address: bookings.address,
  city: bookings.city,
  notes: bookings.notes,
  status: bookings.status,
  createdAt: bookings.createdAt,
  nurseName: nurses.name,
  nursePhoto: nurses.photo,
  nurseSlug: nurses.slug,
};

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const phone = searchParams.get("phone");
    const nurseIdParam = searchParams.get("nurseId");

    let whereClause;
    if (phone) {
      const normalized = phone.replace(/[\s.-]/g, "");
      whereClause = sql`replace(replace(replace(${bookings.patientPhone}, ' ', ''), '-', ''), '.', '') = ${normalized}`;
    } else if (nurseIdParam) {
      const nurseId = Number(nurseIdParam);
      if (!Number.isFinite(nurseId)) {
        return NextResponse.json({ error: "nurseId invalide." }, { status: 400 });
      }
      whereClause = eq(bookings.nurseId, nurseId);
    } else {
      return NextResponse.json(
        { error: "Paramètre phone ou nurseId requis." },
        { status: 400 },
      );
    }

    const list = await db
      .select(bookingWithNurse)
      .from(bookings)
      .innerJoin(nurses, eq(bookings.nurseId, nurses.id))
      .where(whereClause)
      .orderBy(desc(bookings.createdAt));

    return NextResponse.json({ bookings: list });
  } catch (err) {
    console.error("GET /api/bookings", err);
    return NextResponse.json(
      { error: "Impossible de charger les rendez-vous." },
      { status: 500 },
    );
  }
}

export async function POST(req: Request) {
  try {
    const body = (await req.json()) as Record<string, unknown>;

    const nurseId = Number(body.nurseId);
    const serviceName = String(body.serviceName ?? "").trim();
    const patientName = String(body.patientName ?? "").trim();
    const patientPhone = String(body.patientPhone ?? "").trim();
    const date = String(body.date ?? "").trim();
    const timeSlot = String(body.timeSlot ?? "").trim();
    const address = String(body.address ?? "").trim();
    const city = String(body.city ?? "").trim();
    const notes =
      body.notes && String(body.notes).trim() ? String(body.notes).trim() : null;

    const errors: string[] = [];
    if (!Number.isFinite(nurseId)) errors.push("Infirmier invalide.");
    if (!serviceName) errors.push("Le type de soin est requis.");
    if (patientName.length < 3) errors.push("Nom du patient invalide.");
    if (patientPhone.replace(/\D/g, "").length < 9)
      errors.push("Numéro de téléphone invalide.");
    if (!/^\d{4}-\d{2}-\d{2}$/.test(date)) errors.push("Date invalide.");
    if (!timeSlot) errors.push("Choisissez un créneau horaire.");
    if (address.length < 5) errors.push("Adresse trop courte.");
    if (!city) errors.push("La ville est requise.");

    if (errors.length) {
      return NextResponse.json({ error: errors.join(" ") }, { status: 400 });
    }

    const [nurse] = await db.select().from(nurses).where(eq(nurses.id, nurseId));
    if (!nurse) {
      return NextResponse.json(
        { error: "Cet infirmier n'existe pas." },
        { status: 404 },
      );
    }

    const reference = `SH-${Date.now().toString(36).toUpperCase().slice(-4)}${Math.floor(
      10 + Math.random() * 90,
    )}`;

    const [booking] = await db
      .insert(bookings)
      .values({
        reference,
        nurseId,
        serviceName,
        patientName,
        patientPhone,
        date,
        timeSlot,
        address,
        city,
        notes,
        status: "pending",
      })
      .returning();

    return NextResponse.json({ booking }, { status: 201 });
  } catch (err) {
    console.error("POST /api/bookings", err);
    return NextResponse.json(
      { error: "La demande n'a pas pu être envoyée. Réessayez." },
      { status: 500 },
    );
  }
}

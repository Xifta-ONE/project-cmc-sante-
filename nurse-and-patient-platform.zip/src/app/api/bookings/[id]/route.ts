import { NextResponse } from "next/server";
import { eq } from "drizzle-orm";
import { db } from "@/db";
import { bookings } from "@/db/schema";

export const dynamic = "force-dynamic";

const ALLOWED = ["pending", "confirmed", "completed", "cancelled"] as const;

export async function PATCH(
  req: Request,
  { params }: { params: Promise<{ id: string }> },
) {
  try {
    const { id } = await params;
    const bookingId = Number(id);
    if (!Number.isFinite(bookingId)) {
      return NextResponse.json({ error: "Identifiant invalide." }, { status: 400 });
    }

    const body = (await req.json()) as { status?: string };
    const status = body.status;
    if (!status || !ALLOWED.includes(status as (typeof ALLOWED)[number])) {
      return NextResponse.json({ error: "Statut invalide." }, { status: 400 });
    }

    const [updated] = await db
      .update(bookings)
      .set({ status: status as (typeof ALLOWED)[number] })
      .where(eq(bookings.id, bookingId))
      .returning();

    if (!updated) {
      return NextResponse.json(
        { error: "Réservation introuvable." },
        { status: 404 },
      );
    }

    return NextResponse.json({ booking: updated });
  } catch (err) {
    console.error("PATCH /api/bookings/[id]", err);
    return NextResponse.json(
      { error: "Mise à jour impossible." },
      { status: 500 },
    );
  }
}

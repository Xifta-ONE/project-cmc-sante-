import { NextResponse } from "next/server";
import { desc, eq } from "drizzle-orm";
import { db } from "@/db";
import { nurses, reviews } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function GET(
  _req: Request,
  { params }: { params: Promise<{ slug: string }> },
) {
  try {
    const { slug } = await params;
    const [nurse] = await db.select().from(nurses).where(eq(nurses.slug, slug));
    if (!nurse) {
      return NextResponse.json(
        { error: "Infirmier introuvable." },
        { status: 404 },
      );
    }
    const nurseReviews = await db
      .select()
      .from(reviews)
      .where(eq(reviews.nurseId, nurse.id))
      .orderBy(desc(reviews.createdAt));

    return NextResponse.json({ nurse, reviews: nurseReviews });
  } catch (err) {
    console.error("GET /api/nurses/[slug]", err);
    return NextResponse.json(
      { error: "Impossible de charger ce profil." },
      { status: 500 },
    );
  }
}

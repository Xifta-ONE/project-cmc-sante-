import { NextResponse } from "next/server";
import { and, asc, desc, eq, ilike } from "drizzle-orm";
import { db } from "@/db";
import { nurses } from "@/db/schema";

export const dynamic = "force-dynamic";

export async function GET(req: Request) {
  try {
    const { searchParams } = new URL(req.url);
    const ville = searchParams.get("ville");
    const specialite = searchParams.get("specialite");
    const q = searchParams.get("q");
    const tri = searchParams.get("tri") ?? "rating";

    const conditions = [];
    if (ville) conditions.push(eq(nurses.city, ville));
    if (specialite) conditions.push(eq(nurses.specialty, specialite));
    if (q) conditions.push(ilike(nurses.name, `%${q}%`));

    const orderBy =
      tri === "prix-asc"
        ? [asc(nurses.pricePerVisit)]
        : tri === "prix-desc"
          ? [desc(nurses.pricePerVisit)]
          : tri === "experience"
            ? [desc(nurses.yearsExperience)]
            : [desc(nurses.rating)];

    const list = await db
      .select()
      .from(nurses)
      .where(conditions.length ? and(...conditions) : undefined)
      .orderBy(...orderBy);

    return NextResponse.json({ nurses: list });
  } catch (err) {
    console.error("GET /api/nurses", err);
    return NextResponse.json(
      { error: "Impossible de charger les infirmiers." },
      { status: 500 },
    );
  }
}

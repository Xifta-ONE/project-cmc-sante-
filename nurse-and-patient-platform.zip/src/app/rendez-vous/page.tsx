import type { Metadata } from "next";
import { Tracker } from "@/components/tracker";

export const metadata: Metadata = {
  title: "Suivre mes rendez-vous — Shifa",
  description:
    "Suivez l'état de vos demandes de visite à domicile : envoyée, confirmée, réalisée. Annulation gratuite jusqu'à 2h avant.",
};

export default async function RendezVousPage({
  searchParams,
}: {
  searchParams: Promise<{ tel?: string }>;
}) {
  const { tel } = await searchParams;
  return (
    <main>
      <Tracker initialPhone={tel ?? ""} />
    </main>
  );
}
